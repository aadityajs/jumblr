-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 16, 2011 at 02:33 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `get_deals`
--

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_admin`
--

CREATE TABLE IF NOT EXISTS `getdeals_admin` (
  `admin_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `privileges` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `getdeals_admin`
--

INSERT INTO `getdeals_admin` (`admin_id`, `admin_name`, `admin_password`, `email`, `status`, `privileges`, `date_added`) VALUES
(1, 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 'getdeals@gmail.com', 1, 'manage_user,manage_deal,manage_admin,manage_merchant,manage_dealcategory,manage_city,manage_staticpage,manage_faq	', '2011-11-14 11:13:42'),
(19, 'admin2', 'e10adc3949ba59abbe56e057f20f883e', 'admin@@wakadeals.com', 1, 'manage_user,manage_deal,manage_city,manage_staticpage', '2011-08-23 19:56:54'),
(20, 'anindya', 'e10adc3949ba59abbe56e057f20f883e', 'anindya@unified.com', 1, 'manage_deal', '2011-08-24 10:57:34');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_advertisements`
--

CREATE TABLE IF NOT EXISTS `getdeals_advertisements` (
  `adv_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `adv_name` varchar(75) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `adv_url` varchar(100) NOT NULL,
  `adv_image` varchar(100) NOT NULL,
  `adv_from` varchar(50) NOT NULL,
  `adv_to` varchar(50) NOT NULL,
  `adv_city` varchar(100) NOT NULL,
  `adv_status` tinyint(4) NOT NULL,
  `adv_added` date NOT NULL,
  PRIMARY KEY (`adv_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `getdeals_advertisements`
--

INSERT INTO `getdeals_advertisements` (`adv_id`, `adv_name`, `merchant_id`, `adv_url`, `adv_image`, `adv_from`, `adv_to`, `adv_city`, `adv_status`, `adv_added`) VALUES
(1, 'Test Advertisement', 1, 'http://www.groupon.com/winnipeg/', 'Lux-For-Sprouts.jpg', '03-07-2011 13:43', '03-10-2011 13:43', '', 1, '2011-03-07'),
(2, 'Adv 2', 0, 'http://www.groupon.com/edmonton/', '4147f961-4d71-4d4e-ac30-958aebf22913-280_q60-jpg.jpg', '03-07-2011 13:46', '03-16-2011 13:46', '', 1, '2011-07-21');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_buck_percent`
--

CREATE TABLE IF NOT EXISTS `getdeals_buck_percent` (
  `percent_id` int(11) NOT NULL AUTO_INCREMENT,
  `percent` float NOT NULL,
  PRIMARY KEY (`percent_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `getdeals_buck_percent`
--

INSERT INTO `getdeals_buck_percent` (`percent_id`, `percent`) VALUES
(3, 20),
(4, 30),
(5, 40);

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_buck_tracker`
--

CREATE TABLE IF NOT EXISTS `getdeals_buck_tracker` (
  `tracker_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `purchase_date` datetime NOT NULL,
  PRIMARY KEY (`tracker_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `getdeals_buck_tracker`
--

INSERT INTO `getdeals_buck_tracker` (`tracker_id`, `user_id`, `deal_id`, `friend_id`, `purchase_date`) VALUES
(1, 20, 12, 61, '2011-08-09 05:11:00'),
(3, 20, 12, 62, '2011-08-09 05:44:00');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_buck_transaction`
--

CREATE TABLE IF NOT EXISTS `getdeals_buck_transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `deal_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `price` float NOT NULL,
  `tran_date` datetime NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `getdeals_buck_transaction`
--

INSERT INTO `getdeals_buck_transaction` (`transaction_id`, `deal_id`, `user_id`, `price`, `tran_date`) VALUES
(1, 12, 20, 2, '2011-08-10 09:53:13'),
(2, 12, 20, 2, '2011-08-10 10:18:55'),
(3, 12, 20, 1, '2011-08-10 11:55:17'),
(4, 12, 20, 1, '2011-08-10 12:05:47'),
(5, 12, 20, 1, '2011-08-10 12:46:44'),
(6, 11, 20, 0.8, '2011-08-16 05:43:19');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_buck_vault`
--

CREATE TABLE IF NOT EXISTS `getdeals_buck_vault` (
  `buck_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  `amount` float NOT NULL,
  `receive_date` datetime NOT NULL,
  PRIMARY KEY (`buck_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `getdeals_buck_vault`
--

INSERT INTO `getdeals_buck_vault` (`buck_id`, `user_id`, `deal_id`, `amount`, `receive_date`) VALUES
(2, 20, 12, 25, '2011-08-09 05:44:00');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_categories`
--

CREATE TABLE IF NOT EXISTS `getdeals_categories` (
  `cat_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `date_added` date NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=170 ;

--
-- Dumping data for table `getdeals_categories`
--

INSERT INTO `getdeals_categories` (`cat_id`, `parent_id`, `cat_name`, `image`, `status`, `date_added`) VALUES
(157, 0, 'Casual Dining', '1299268414808.jpg', 1, '2011-07-21'),
(2, 0, 'Fine Dining', 'MICHELINOS-TRATTORIA-HERO-6.jpg', 1, '2011-07-21'),
(156, 0, 'Fitness', '1299660298487.jpg', 1, '2011-07-21'),
(155, 0, 'Beauty & Relaxsation', '1300360614176.jpg', 1, '2011-07-21'),
(154, 0, 'Travel Gateways', 'Bear-Mountain-Resort2.jpg', 1, '2011-07-21');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_cities`
--

CREATE TABLE IF NOT EXISTS `getdeals_cities` (
  `city_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `country_id` bigint(20) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `date_added` date NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `getdeals_cities`
--

INSERT INTO `getdeals_cities` (`city_id`, `country_id`, `city_name`, `description`, `status`, `date_added`) VALUES
(1, 226, 'Illinois', '<h1>Cras congue ullamcorper <span>augue non lacinia.</span></h1>\r\n<p>Phasellus tempor ornare neque eget accumsan. Pellentesque bibendum   lectus non ante accumsan viverra. Aenean id velit risus, nec ultrices   orci? Donec ultricies leo vel velit varius sed gravida dui congue.   Maecenas arcu nulla, sagittis ac lobortis vitae, varius sagittis odio?   Suspendisse potenti. Cras congue ullamcorper augunon lacinia. Nullam   facilisis arcu quis purus scelerisque id tempus nulla consectetur.</p>\r\n<p>Phasellus tempor ornare neque eget accumsan.  Pellentesque bibendum  lectus non ante accumsan viverra. Aenean id velit  risus, nec ultrices  orci? Donec ultricies leo vel velit varius sed  gravida dui congue.  Maecenas arcu nulla, sagittis ac lobortis vitae,  varius sagittis odio?  Suspendisse potenti. Cras congue ullamcorper  augunon lacinia. Nullam  facilisis arcu quis purus scelerisque id tempus  nulla consectetur.</p>', 1, '2011-08-11'),
(2, 226, 'New York', '<h1>Cras congue ullamcorper <span>augue non lacinia.</span></h1>\r\n<p>Phasellus tempor ornare neque eget accumsan. Pellentesque bibendum   lectus non ante accumsan viverra. Aenean id velit risus, nec ultrices   orci? Donec ultricies leo vel velit varius sed gravida dui congue.   Maecenas arcu nulla, sagittis ac lobortis vitae, varius sagittis odio?   Suspendisse potenti. Cras congue ullamcorper augunon lacinia. Nullam   facilisis arcu quis purus scelerisque id tempus nulla consectetur.</p>\r\n<p>Phasellus tempor ornare neque eget accumsan.  Pellentesque bibendum  lectus non ante accumsan viverra. Aenean id velit  risus, nec ultrices  orci? Donec ultricies leo vel velit varius sed  gravida dui congue.  Maecenas arcu nulla, sagittis ac lobortis vitae,  varius sagittis odio?  Suspendisse potenti. Cras congue ullamcorper  augunon lacinia. Nullam  facilisis arcu quis purus scelerisque id tempus  nulla consectetur.</p>', 1, '2011-08-11'),
(3, 226, 'Atlanta', '<h1>Cras congue ullamcorper <span>augue non lacinia.</span></h1>\r\n<p>Phasellus tempor ornare neque eget accumsan. Pellentesque bibendum   lectus non ante accumsan viverra. Aenean id velit risus, nec ultrices   orci? Donec ultricies leo vel velit varius sed gravida dui congue.   Maecenas arcu nulla, sagittis ac lobortis vitae, varius sagittis odio?   Suspendisse potenti. Cras congue ullamcorper augunon lacinia. Nullam   facilisis arcu quis purus scelerisque id tempus nulla consectetur.</p>\r\n<p>Phasellus tempor ornare neque eget accumsan.  Pellentesque bibendum  lectus non ante accumsan viverra. Aenean id velit  risus, nec ultrices  orci? Donec ultricies leo vel velit varius sed  gravida dui congue.  Maecenas arcu nulla, sagittis ac lobortis vitae,  varius sagittis odio?  Suspendisse potenti. Cras congue ullamcorper  augunon lacinia. Nullam  facilisis arcu quis purus scelerisque id tempus  nulla consectetur.</p>', 1, '2011-08-11'),
(4, 226, 'Boston', '<h1>Cras congue ullamcorper <span>augue non lacinia.</span></h1>\r\n<p>Phasellus tempor ornare neque eget accumsan. Pellentesque bibendum  lectus non ante accumsan viverra. Aenean id velit risus, nec ultrices  orci? Donec ultricies leo vel velit varius sed gravida dui congue.  Maecenas arcu nulla, sagittis ac lobortis vitae, varius sagittis odio?  Suspendisse potenti. Cras congue ullamcorper augunon lacinia. Nullam  facilisis arcu quis purus scelerisque id tempus nulla consectetur.</p>\r\n<p>Phasellus tempor ornare neque eget accumsan.  Pellentesque bibendum lectus non ante accumsan viverra. Aenean id velit  risus, nec ultrices orci? Donec ultricies leo vel velit varius sed  gravida dui congue. Maecenas arcu nulla, sagittis ac lobortis vitae,  varius sagittis odio? Suspendisse potenti. Cras congue ullamcorper  augunon lacinia. Nullam facilisis arcu quis purus scelerisque id tempus  nulla consectetur.</p>\r\n<p>&nbsp;</p>', 1, '2011-08-11'),
(5, 226, 'Chicago', '<h1>Cras congue ullamcorper <span>augue non lacinia.</span></h1>\r\n<p>Phasellus tempor ornare neque eget accumsan. Pellentesque bibendum   lectus non ante accumsan viverra. Aenean id velit risus, nec ultrices   orci? Donec ultricies leo vel velit varius sed gravida dui congue.   Maecenas arcu nulla, sagittis ac lobortis vitae, varius sagittis odio?   Suspendisse potenti. Cras congue ullamcorper augunon lacinia. Nullam   facilisis arcu quis purus scelerisque id tempus nulla consectetur.</p>\r\n<p>Phasellus tempor ornare neque eget accumsan.  Pellentesque bibendum  lectus non ante accumsan viverra. Aenean id velit  risus, nec ultrices  orci? Donec ultricies leo vel velit varius sed  gravida dui congue.  Maecenas arcu nulla, sagittis ac lobortis vitae,  varius sagittis odio?  Suspendisse potenti. Cras congue ullamcorper  augunon lacinia. Nullam  facilisis arcu quis purus scelerisque id tempus  nulla consectetur.</p>', 1, '2011-08-11'),
(6, 226, 'Washington DC', '<h1>Cras congue ullamcorper <span>augue non lacinia.</span></h1>\r\n<p>Phasellus tempor ornare neque eget accumsan. Pellentesque bibendum   lectus non ante accumsan viverra. Aenean id velit risus, nec ultrices   orci? Donec ultricies leo vel velit varius sed gravida dui congue.   Maecenas arcu nulla, sagittis ac lobortis vitae, varius sagittis odio?   Suspendisse potenti. Cras congue ullamcorper augunon lacinia. Nullam   facilisis arcu quis purus scelerisque id tempus nulla consectetur.</p>\r\n<p>Phasellus tempor ornare neque eget accumsan.  Pellentesque bibendum  lectus non ante accumsan viverra. Aenean id velit  risus, nec ultrices  orci? Donec ultricies leo vel velit varius sed  gravida dui congue.  Maecenas arcu nulla, sagittis ac lobortis vitae,  varius sagittis odio?  Suspendisse potenti. Cras congue ullamcorper  augunon lacinia. Nullam  facilisis arcu quis purus scelerisque id tempus  nulla consectetur.</p>', 1, '2011-08-11'),
(7, 226, 'Los Angles', '<h1>Cras congue ullamcorper <span>augue non lacinia.</span></h1>\r\n<p>Phasellus tempor ornare neque eget accumsan. Pellentesque bibendum   lectus non ante accumsan viverra. Aenean id velit risus, nec ultrices   orci? Donec ultricies leo vel velit varius sed gravida dui congue.   Maecenas arcu nulla, sagittis ac lobortis vitae, varius sagittis odio?   Suspendisse potenti. Cras congue ullamcorper augunon lacinia. Nullam   facilisis arcu quis purus scelerisque id tempus nulla consectetur.</p>\r\n<p>Phasellus tempor ornare neque eget accumsan.  Pellentesque bibendum  lectus non ante accumsan viverra. Aenean id velit  risus, nec ultrices  orci? Donec ultricies leo vel velit varius sed  gravida dui congue.  Maecenas arcu nulla, sagittis ac lobortis vitae,  varius sagittis odio?  Suspendisse potenti. Cras congue ullamcorper  augunon lacinia. Nullam  facilisis arcu quis purus scelerisque id tempus  nulla consectetur.</p>', 1, '2011-08-11');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_cities_image`
--

CREATE TABLE IF NOT EXISTS `getdeals_cities_image` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`image_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `getdeals_cities_image`
--

INSERT INTO `getdeals_cities_image` (`image_id`, `city_id`, `file`) VALUES
(32, 1, 'Downtown_Chicago_Illinois_Nov05_img_2670.jpg'),
(31, 1, 'illinois-tax-help.jpg'),
(36, 2, 'central-park-new-york-wallpaper.jpg'),
(35, 2, 'NY(1)(1).jpg'),
(34, 2, 'new-york3.jpg'),
(50, 3, 'atlanta_skyline4_2.jpg'),
(49, 3, '201606_atlanta_usa_olympic_park.jpg'),
(48, 3, 'georgia-atlanta.jpg'),
(37, 4, 'Boston-USA_01-rl-2010-04-21.jpg'),
(41, 5, 'Chicago River- Chicago,USA.jpg'),
(40, 5, 'ChicagoSkyline1.jpg'),
(39, 5, 'Chicago-USA-004.jpg'),
(54, 6, 'Washington-DC.jpg'),
(53, 6, 'city-of-washington2.jpg'),
(47, 7, 'Los_Angeles-Hollywood_boulevard_from_kodak_theatre.jpg'),
(46, 7, 'los_angeles-3.jpg'),
(45, 7, 'Los-Angeles-city.jpg'),
(44, 7, 'los_angeles_ca.jpg'),
(43, 7, 'Los_angeles.jpg'),
(42, 7, 'los-angeles-skyline.jpg'),
(33, 1, 'downtown_chicago_illinois_1024x768.jpg'),
(38, 4, '12591313.jpg'),
(51, 3, 'images1.jpg'),
(52, 3, 'images.jpg'),
(55, 6, 'washington.jpg'),
(56, 4, 'Winter.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_commissions`
--

CREATE TABLE IF NOT EXISTS `getdeals_commissions` (
  `comm_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mid` bigint(20) NOT NULL,
  `comm_amt` decimal(10,2) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`comm_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `getdeals_commissions`
--

INSERT INTO `getdeals_commissions` (`comm_id`, `mid`, `comm_amt`, `status`) VALUES
(1, 1, 12.33, 1),
(3, 2, 41.99, 1);

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_countries`
--

CREATE TABLE IF NOT EXISTS `getdeals_countries` (
  `country_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(80) NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=240 ;

--
-- Dumping data for table `getdeals_countries`
--

INSERT INTO `getdeals_countries` (`country_id`, `country_name`) VALUES
(1, 'Afghanistan'),
(2, 'Albania'),
(3, 'Algeria'),
(4, 'American Samoa'),
(5, 'Andorra'),
(6, 'Angola'),
(7, 'Anguilla'),
(8, 'Antarctica'),
(9, 'Antigua and Barbuda'),
(10, 'Argentina'),
(11, 'Armenia'),
(12, 'Aruba'),
(13, 'Australia'),
(14, 'Austria'),
(15, 'Azerbaijan'),
(16, 'Bahamas'),
(17, 'Bahrain'),
(18, 'Bangladesh'),
(19, 'Barbados'),
(20, 'Belarus'),
(21, 'Belgium'),
(22, 'Belize'),
(23, 'Benin'),
(24, 'Bermuda'),
(25, 'Bhutan'),
(26, 'Bolivia'),
(27, 'Bosnia and Herzegovina'),
(28, 'Botswana'),
(29, 'Bouvet Island'),
(30, 'Brazil'),
(31, 'British Indian Ocean Territory'),
(32, 'Brunei Darussalam'),
(33, 'Bulgaria'),
(34, 'Burkina Faso'),
(35, 'Burundi'),
(36, 'Cambodia'),
(37, 'Cameroon'),
(38, 'Canada'),
(39, 'Cape Verde'),
(40, 'Cayman Islands'),
(41, 'Central African Republic'),
(42, 'Chad'),
(43, 'Chile'),
(44, 'China'),
(45, 'Christmas Island'),
(46, 'Cocos (Keeling) Islands'),
(47, 'Colombia'),
(48, 'Comoros'),
(49, 'Congo'),
(50, 'Congo, the Democratic Republic of the'),
(51, 'Cook Islands'),
(52, 'Costa Rica'),
(53, 'Cote D''Ivoire'),
(54, 'Croatia'),
(55, 'Cuba'),
(56, 'Cyprus'),
(57, 'Czech Republic'),
(58, 'Denmark'),
(59, 'Djibouti'),
(60, 'Dominica'),
(61, 'Dominican Republic'),
(62, 'Ecuador'),
(63, 'Egypt'),
(64, 'El Salvador'),
(65, 'Equatorial Guinea'),
(66, 'Eritrea'),
(67, 'Estonia'),
(68, 'Ethiopia'),
(69, 'Falkland Islands (Malvinas)'),
(70, 'Faroe Islands'),
(71, 'Fiji'),
(72, 'Finland'),
(73, 'France'),
(74, 'French Guiana'),
(75, 'French Polynesia'),
(76, 'French Southern Territories'),
(77, 'Gabon'),
(78, 'Gambia'),
(79, 'Georgia'),
(80, 'Germany'),
(81, 'Ghana'),
(82, 'Gibraltar'),
(83, 'Greece'),
(84, 'Greenland'),
(85, 'Grenada'),
(86, 'Guadeloupe'),
(87, 'Guam'),
(88, 'Guatemala'),
(89, 'Guinea'),
(90, 'Guinea-Bissau'),
(91, 'Guyana'),
(92, 'Haiti'),
(93, 'Heard Island and Mcdonald Islands'),
(94, 'Holy See (Vatican City State)'),
(95, 'Honduras'),
(96, 'Hong Kong'),
(97, 'Hungary'),
(98, 'Iceland'),
(99, 'India'),
(100, 'Indonesia'),
(101, 'Iran, Islamic Republic of'),
(102, 'Iraq'),
(103, 'Ireland'),
(104, 'Israel'),
(105, 'Italy'),
(106, 'Jamaica'),
(107, 'Japan'),
(108, 'Jordan'),
(109, 'Kazakhstan'),
(110, 'Kenya'),
(111, 'Kiribati'),
(112, 'Korea, Democratic People''s Republic of'),
(113, 'Korea, Republic of'),
(114, 'Kuwait'),
(115, 'Kyrgyzstan'),
(116, 'Lao People''s Democratic Republic'),
(117, 'Latvia'),
(118, 'Lebanon'),
(119, 'Lesotho'),
(120, 'Liberia'),
(121, 'Libyan Arab Jamahiriya'),
(122, 'Liechtenstein'),
(123, 'Lithuania'),
(124, 'Luxembourg'),
(125, 'Macao'),
(126, 'Macedonia, the Former Yugoslav Republic of'),
(127, 'Madagascar'),
(128, 'Malawi'),
(129, 'Malaysia'),
(130, 'Maldives'),
(131, 'Mali'),
(132, 'Malta'),
(133, 'Marshall Islands'),
(134, 'Martinique'),
(135, 'Mauritania'),
(136, 'Mauritius'),
(137, 'Mayotte'),
(138, 'Mexico'),
(139, 'Micronesia, Federated States of'),
(140, 'Moldova, Republic of'),
(141, 'Monaco'),
(142, 'Mongolia'),
(143, 'Montserrat'),
(144, 'Morocco'),
(145, 'Mozambique'),
(146, 'Myanmar'),
(147, 'Namibia'),
(148, 'Nauru'),
(149, 'Nepal'),
(150, 'Netherlands'),
(151, 'Netherlands Antilles'),
(152, 'New Caledonia'),
(153, 'New Zealand'),
(154, 'Nicaragua'),
(155, 'Niger'),
(156, 'Nigeria'),
(157, 'Niue'),
(158, 'Norfolk Island'),
(159, 'Northern Mariana Islands'),
(160, 'Norway'),
(161, 'Oman'),
(162, 'Pakistan'),
(163, 'Palau'),
(164, 'Palestinian Territory, Occupied'),
(165, 'Panama'),
(166, 'Papua New Guinea'),
(167, 'Paraguay'),
(168, 'Peru'),
(169, 'Philippines'),
(170, 'Pitcairn'),
(171, 'Poland'),
(172, 'Portugal'),
(173, 'Puerto Rico'),
(174, 'Qatar'),
(175, 'Reunion'),
(176, 'Romania'),
(177, 'Russian Federation'),
(178, 'Rwanda'),
(179, 'Saint Helena'),
(180, 'Saint Kitts and Nevis'),
(181, 'Saint Lucia'),
(182, 'Saint Pierre and Miquelon'),
(183, 'Saint Vincent and the Grenadines'),
(184, 'Samoa'),
(185, 'San Marino'),
(186, 'Sao Tome and Principe'),
(187, 'Saudi Arabia'),
(188, 'Senegal'),
(189, 'Serbia and Montenegro'),
(190, 'Seychelles'),
(191, 'Sierra Leone'),
(192, 'Singapore'),
(193, 'Slovakia'),
(194, 'Slovenia'),
(195, 'Solomon Islands'),
(196, 'Somalia'),
(197, 'South Africa'),
(198, 'South Georgia and the South Sandwich Islands'),
(199, 'Spain'),
(200, 'Sri Lanka'),
(201, 'Sudan'),
(202, 'Suriname'),
(203, 'Svalbard and Jan Mayen'),
(204, 'Swaziland'),
(205, 'Sweden'),
(206, 'Switzerland'),
(207, 'Syrian Arab Republic'),
(208, 'Taiwan, Province of China'),
(209, 'Tajikistan'),
(210, 'Tanzania, United Republic of'),
(211, 'Thailand'),
(212, 'Timor-Leste'),
(213, 'Togo'),
(214, 'Tokelau'),
(215, 'Tonga'),
(216, 'Trinidad and Tobago'),
(217, 'Tunisia'),
(218, 'Turkey'),
(219, 'Turkmenistan'),
(220, 'Turks and Caicos Islands'),
(221, 'Tuvalu'),
(222, 'Uganda'),
(223, 'Ukraine'),
(224, 'United Arab Emirates'),
(225, 'United Kingdom'),
(226, 'United States'),
(227, 'United States Minor Outlying Islands'),
(228, 'Uruguay'),
(229, 'Uzbekistan'),
(230, 'Vanuatu'),
(231, 'Venezuela'),
(232, 'Viet Nam'),
(233, 'Virgin Islands, British'),
(234, 'Virgin Islands, U.s.'),
(235, 'Wallis and Futuna'),
(236, 'Western Sahara'),
(237, 'Yemen'),
(238, 'Zambia'),
(239, 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_coupons`
--

CREATE TABLE IF NOT EXISTS `getdeals_coupons` (
  `coupon_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `coupon_status` enum('available','used','expired','redeemed') NOT NULL,
  `coupon_code` varchar(255) NOT NULL,
  `purchase_date` datetime NOT NULL,
  `expire_date` datetime NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  PRIMARY KEY (`coupon_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `getdeals_coupons`
--


-- --------------------------------------------------------

--
-- Table structure for table `getdeals_deals`
--

CREATE TABLE IF NOT EXISTS `getdeals_deals` (
  `deal_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `deal_cat` bigint(20) NOT NULL,
  `store_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `deal_subcat` bigint(20) NOT NULL,
  `address1` varbinary(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `city` varchar(200) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `country` int(11) NOT NULL,
  `website` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `title2` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `menu_item` text NOT NULL,
  `people_review` text NOT NULL,
  `offer_details` text NOT NULL,
  `offer_details_sidebar` text NOT NULL,
  `highlights` text NOT NULL,
  `fineprint` text NOT NULL,
  `deal_image` varchar(150) NOT NULL,
  `full_price` float NOT NULL,
  `getdeals_comission` float NOT NULL,
  `discounted_price` float NOT NULL,
  `custpercent` float NOT NULL,
  `merchant_take` float NOT NULL,
  `merchantpercent` float NOT NULL,
  `waka_percent` float NOT NULL,
  `wakadealsbuck_price` float NOT NULL,
  `deal_start_time` datetime NOT NULL,
  `deal_end_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `best_deal` enum('y','n') NOT NULL DEFAULT 'n',
  `item_type` varchar(255) NOT NULL,
  `item_control_type` enum('checkbox','radio') NOT NULL,
  `mid` bigint(20) NOT NULL,
  `admin_id` bigint(20) NOT NULL,
  `coupon_expiry` varchar(50) NOT NULL,
  `min_coupons` int(11) NOT NULL,
  `max_coupons` int(11) NOT NULL,
  `max_purchase` int(11) NOT NULL,
  `max_buy` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deal_currency` varchar(10) NOT NULL,
  `commission_percentage` decimal(10,2) NOT NULL,
  `place_lat` varchar(100) NOT NULL,
  `place_lng` varchar(100) NOT NULL,
  `referral_no` int(11) NOT NULL,
  `referral_value` int(11) NOT NULL,
  `buck_percent` float NOT NULL,
  `nowdeal_repeatday` varchar(255) NOT NULL,
  `nowdeal_stopdate` datetime NOT NULL,
  `deal_type` varchar(255) NOT NULL,
  PRIMARY KEY (`deal_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `getdeals_deals`
--

INSERT INTO `getdeals_deals` (`deal_id`, `deal_cat`, `store_id`, `location_id`, `deal_subcat`, `address1`, `address2`, `city`, `zip`, `country`, `website`, `brand`, `title`, `title2`, `description`, `menu_item`, `people_review`, `offer_details`, `offer_details_sidebar`, `highlights`, `fineprint`, `deal_image`, `full_price`, `getdeals_comission`, `discounted_price`, `custpercent`, `merchant_take`, `merchantpercent`, `waka_percent`, `wakadealsbuck_price`, `deal_start_time`, `deal_end_time`, `status`, `best_deal`, `item_type`, `item_control_type`, `mid`, `admin_id`, `coupon_expiry`, `min_coupons`, `max_coupons`, `max_purchase`, `max_buy`, `date_added`, `date_modified`, `deal_currency`, `commission_percentage`, `place_lat`, `place_lng`, `referral_no`, `referral_value`, `buck_percent`, `nowdeal_repeatday`, `nowdeal_stopdate`, `deal_type`) VALUES
(59, 2, 2, 2, 0, '', '', '', '', 0, 'www.spa.com', '', '$50.00 for $60.00 at store1<br>16.67 % off spa &amp; resturants', '', 'spa & resturants', '', '', '<p>This is spa center</p>', '', '', '', '', 60, 17.5, 50, 16, 32.5, 65, 35, 0, '2011-10-24 14:46:00', '2011-10-27 14:46:00', 1, 'n', '', '', 2, 0, '', 0, 20, 0, 0, '2011-10-25 00:00:00', '2011-10-25 14:49:29', '', 0.00, '', '', 0, 0, 0, '', '0000-00-00 00:00:00', 'dailydeal'),
(57, 156, 2, 3, 0, '', '', '', '', 0, 'www.fd.com', '', '$20.00 for $50.00 at store1<br>60.00 % off eg. food &amp; drink or travel', '', 'eg. food & drink or travel', '', '', '<p>This is a casual dining offer. Let get food and drinks and enjoy travelling.</p>', '', '', '', '', 50, 7, 20, 60, 13, 65, 35, 0, '2011-10-20 16:58:00', '2011-10-22 16:58:00', 1, 'n', '', '', 2, 0, '', 0, 10, 0, 0, '2011-10-25 00:00:00', '2011-10-21 17:06:24', '', 0.00, '', '', 0, 0, 0, '', '0000-00-00 00:00:00', 'dailydeal'),
(58, 154, 2, 2, 0, '', '', '', '', 0, 'www.tg.com', '', '$30.00 for $80.00 at store1<br>62.50 % off eg. food &amp; drink or travel', '', 'eg. food & drink or travel', '', '', '<p>This is a travel gateway section</p>', '', '', '', '', 80, 10.5, 30, 62, 19.5, 65, 35, 0, '2011-10-20 17:08:00', '2011-10-23 17:08:00', 1, 'n', '', '', 2, 0, '', 0, 10, 0, 0, '2011-10-21 00:00:00', '2011-10-21 17:08:35', '', 0.00, '', '', 0, 0, 0, '', '0000-00-00 00:00:00', 'dailydeal'),
(55, 157, 2, 3, 0, '', '', '', '', 0, 'http://www.website.com', '', '$90.00 for $100.00 at store1<br>10 % off test description', '', 'test description', '', '', '<p>test restrictiontest restrictiontest restrictiontest restrictiontest restriction</p>', '', '', '', '', 100, 22.5, 90, 10, 67.5, 0, 25, 0, '2011-09-22 00:00:00', '2011-09-22 16:15:00', 1, 'n', '', '', 2, 1, '', 0, 0, 2, 2, '2011-09-23 00:00:00', '2011-09-22 18:58:27', '', 0.00, '', '', 3, 5, 0, '', '0000-00-00 00:00:00', 'dailydeal'),
(56, 157, 2, 0, 0, '', '', '', '', 0, '', '', '$10.00 for $20.00 at store1<br>50 % off eg. food &amp; drink or travel', '', 'eg. food & drink or travel', '', '', 'This is a test', '', '', '', '', 20, 2.5, 10, 50, 7.5, 0, 25, 0, '2011-10-11 00:00:00', '2011-10-11 00:00:00', 1, 'n', '', 'checkbox', 2, 0, '', 0, 0, 4, 2, '2011-10-14 00:00:00', '2011-10-14 15:00:37', '', 0.00, '', '', 0, 0, 0, '', '0000-00-00 00:00:00', 'dailydeal'),
(60, 2, 2, 3, 0, '', '', '', '', 0, 'www.google.com', '', '¡Murphy’s Irish Pub - £159 pesos instead of $135 for 1 Celtic Salad + 1 Imported Beer, Margarita or Mojito! See more details...', '', '<p> ¡Murphy’s Irish Pub - £159 pesos instead of $135 for 1 Celtic Salad + 1 Imported Beer, Margarita or Mojito! See more details...</p><p>¡Murphy’s Irish Pub - £159 pesos instead of $135 for 1 Celtic Salad + 1 Imported Beer, Margarita or Mojito! See more details...</p>', '', '', '<div>\r\n<p>One (&pound;59) or Two (&pound;99) Night Stay For Two With Sharing Tapas and Breakfast at The Stuart Hotel (Up to 75% Off)</p>\r\n</div>\r\n<div style="width: 456px; float: left; margin: 0 auto; padding: 8px 10px;"><span>While planks of oak can make a great room feature and are sometimes worth a few bob, if you are looking for a place to stay it''s probably best to specify your boarding needs. Stay with bed and board with today''s Groupon from The Stuart Hotel.</span></div>\r\n<div style="width: 456px; float: left; margin: 0 auto; padding: 8px 10px;"><span>&bull; &pound;59 for a one night stay for two with sharing tapas and full English breakfast (Up to 70% off)<br />\r\n<br />\r\n&bull; &pound;99 for a two night stay for two with sharing tapas full English breakfast each day (Up to 75% off)</span></div>\r\n<div class="clear">&nbsp;</div>\r\n<div style="width: 457px; float: left; margin: 0 10px;"><img alt="" width="253" height="223" hspace="3" vspace="2" src="images/pic.jpg" /><img alt="" width="192" height="223" hspace="3" vspace="2" src="images/pic1.jpg" /></div>\r\n<div class="clear">&nbsp;</div>\r\n<div style="width: 456px; float: left; margin: 0 auto; padding: 8px 10px;"><span>Located in a prime position for active types and casual visitors alike, The Stuart Hotel is just a 30 minute drive from Alton Towers and a few minutes'' walk from shoppers'' haven, Westfield. Kitted out with executive suites and delectable dining and drinking opportunities, The Stuart Hotel''s XS Restaurant serves modern British cuisine, while the Liquid Bar is air-conditioned and spilling over with tasty beverages. Those who arrive by train will find that five minutes'' trotting is all it takes to reach the hotel, while the Riverside Gardens and Guildhall Theatre of the town centre are a four minute hop and skip away. </span></div>\r\n<div class="clear">&nbsp;</div>\r\n<div style="width: 457px; float: left; margin: 0 10px;"><img alt="" width="253" height="223" hspace="3" vspace="2" src="images/pic.jpg" /><img alt="" width="192" height="223" hspace="3" vspace="2" src="images/pic1.jpg" /></div>\r\n<div class="clear">&nbsp;</div>\r\n<div style="width: 456px; float: left; margin: 0 auto; padding: 8px 10px;"><span>Parking up for free, getaway seeking pairs will find a stylish, modern room awaiting them, with all the trimmings of bathrobe, slippers, internet access, and 24 hour room service. Leisurely opportunities are afforded by many nearby attractions and a complimentary day pass to LA Fitness, while appetite-sating can be done in the hotel''s restaurant with a free bottle of house wine accompanying every two main dishes purchased. Tapas including calamari rings, frrittata, chicken skewers and cheese and chilli balls are available to share. A full English breakfast will be provided to see guests on their merry way, filling them up for going homeward bound or looping the rollercoaster loop. </span></div>\r\n<div class="clear">&nbsp;</div>\r\n<div class="deal_voucher">\r\n<div>\r\n<p>Follow these step to get your GeeLaza voucher:</p>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div class="follow">\r\n<div class="follow_left"><img alt="" width="45" height="44" src="images/star01.gif" /></div>\r\n<div class="follow_right">You need to buy the deal</div>\r\n</div>\r\n</div>\r\n<div class="deal_voucher">\r\n<div class="follow">\r\n<div class="follow_left"><img alt="" width="45" height="44" src="images/star02.gif" /></div>\r\n<div class="follow_right">GetDeala will email you the voucher when the deal ends</div>\r\n</div>\r\n</div>\r\n<div class="deal_voucher">\r\n<div class="follow">\r\n<div class="follow_left"><img alt="" width="45" height="44" src="images/star03.gif" /></div>\r\n<div class="follow_right">Your GetDeala voucher will be activates within 24 hours</div>\r\n</div>\r\n</div>\r\n<div class="deal_voucher">\r\n<div class="follow">\r\n<div class="follow_left"><img alt="" width="45" height="44" src="images/star04.gif" /></div>\r\n<div class="follow_right">Go to www(business website where they can redmeem the voucher online)</div>\r\n</div>\r\n</div>\r\n<div class="deal_voucher">\r\n<div class="follow">\r\n<div class="follow_left"><img alt="" width="45" height="44" src="images/star05.gif" /></div>\r\n<div class="follow_right">Go to www(business website where they can redmeem the voucher online)</div>\r\n</div>\r\n</div>\r\n<div class="deal_voucher">\r\n<div class="follow">\r\n<div class="follow_left"><img alt="" width="45" height="44" src="images/star06.gif" /></div>\r\n<div class="follow_right">Go to www(business website where they can redmeem the voucher online)</div>\r\n</div>\r\n</div>\r\n<div class="clear"><img alt="" width="1" height="30" src="images/spacer.gif" /></div>\r\n<div class="follow"><strong>The Stuart Hotel</strong><br />\r\n119 London Road, Derby DE1 2QR<br />\r\n<a href="#">http://www.thestuart.com</a></div>', '<p>The Stuart Hotel</p>\r\n<p><span> 119 London Road<br />\r\nDerby DE1 2QR<br />\r\n<a href="#">http://www.thestuart.com</a></span></p>\r\n<div class="clear">&nbsp;</div>\r\n<div style="margin: 12px auto;"><img alt="" width="189" height="172" class="border" src="images/map.gif" /></div>\r\n<div class="clear">&nbsp;</div>\r\n<div style="margin: 12px auto;">\r\n<p>The Stuart Hotel presented by GeeLaza.co.uk</p>\r\n</div>', '<h2>Highlights</h2>\r\n<ul>\r\n    <li class="arrow_txt" style="width:200px;">Listed in the Good Beer Guide 2009-2011</li>\r\n    <li class="arrow_txt" style="width:200px;">Cask Marque accredited</li>\r\n    <li class="arrow_txt" style="width:200px;">Choose any main course and dessert</li>\r\n    <li class="arrow_txt" style="width:200px;">Locally sourced produce</li>\r\n</ul>', '<h2>The Fine Print</h2>\r\n<ul>\r\n    <li style="width:196px;margin: 0 auto;">Expires 21 January 2012. (Excl. 19 Dec <br />\r\n    2011 to 2 Jan 2012)<br />\r\n    Limit 1 per person, may buy multiple<br />\r\n    as gifts. <strong>Booking required. 24</strong><br />\r\n    <strong>hour cancellation policy. </strong></li>\r\n</ul>', '', 199, 0, 99, 0, 0, 0, 0, 0, '2011-11-16 14:45:00', '2011-11-16 23:45:00', 1, 'y', '', '', 2, 1, '', 0, 100, 0, 0, '2011-11-14 00:00:00', '2011-11-14 14:48:23', '', 0.00, '', '', 12345, 123, 0, '', '0000-00-00 00:00:00', 'dailydeal');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_deal_images`
--

CREATE TABLE IF NOT EXISTS `getdeals_deal_images` (
  `imgid` int(11) NOT NULL AUTO_INCREMENT,
  `deal_id` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `tempid` varchar(255) NOT NULL,
  PRIMARY KEY (`imgid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=106 ;

--
-- Dumping data for table `getdeals_deal_images`
--

INSERT INTO `getdeals_deal_images` (`imgid`, `deal_id`, `file`, `tempid`) VALUES
(7, '13', '1._Tarandowah-Golf-Club.jpg_440267_pixels.jpg', ''),
(8, '13', '159c989d-667c-4d66-b0be-93de6fca0dd4-280_q60-jpg.jpg', ''),
(9, '13', '96158343.TrUkDc6y.jpg', ''),
(12, '15', '_birds_wallpaper_19.jpg', ''),
(14, '15', '96158343.TrUkDc6y.jpg', ''),
(48, '1', 'img2.jpg', ''),
(49, '2', 'Gabutto-Burger3.jpg', ''),
(50, '2', 'MICHELINOS-TRATTORIA-HERO-6.jpg', ''),
(72, '28', '_birds_wallpaper_19.jpg', ''),
(24, '4', 'catagory_img2.png', ''),
(25, '4', 'bg.jpg', ''),
(26, '4', 'img1.gif', ''),
(46, '12', 'img1.gif', ''),
(45, '12', '_birds_wallpaper_19.jpg', ''),
(69, '28', '1299499020203.jpg', ''),
(51, '2', 'burger-king-drops-prices-in-israel.jpg', ''),
(52, '5', 'chickenville1.jpg', ''),
(53, '11', 'grande_117_chickenville.jpg', ''),
(54, '11', '1299092721506.jpg', ''),
(55, '3', 'Bear-Mountain-Resort2.jpg', ''),
(56, '3', 'Golf-3.jpg', ''),
(57, '3', 'golf courses.jpg', ''),
(58, '3', 'GolfClub.jpg', ''),
(60, '22', '1291205691617.jpg', ''),
(65, '26', 'Urban-Body-Health-Spa.jpg', ''),
(61, '22', '1299259433476.jpg', ''),
(64, '26', 'The-Hair-Force.jpg', ''),
(66, '26', 'Stella-_-Dot.jpg', ''),
(68, '27', '2009_los_angeles-016.jpg', ''),
(77, '42', '4e72d5438484b1234.jpg', ''),
(75, '41', '4e70b7b938d86060310-130..jpg', ''),
(78, '43', '4e72e2c3a09a92009_los_angeles-016.jpg', ''),
(80, '1', 'Sunset.jpg', ''),
(81, '4e97f3e457041', 'Sunset.jpg', ''),
(83, '4e97f41753337', 'Blue hills.jpg', ''),
(84, '1', 'Blue hills.jpg', ''),
(93, '4e9814f30e895', 'Winter.jpg', ''),
(100, '56', 'burger-king-drops-prices-in-israel.jpg', ''),
(94, '20111019115524', 'spa_signature (1).jpg', ''),
(95, '20111019115524', 'spa_signature (1).jpg', ''),
(96, '55', 'spa_signature.jpg', ''),
(101, '57', 'img1.gif', ''),
(102, '58', 'grande_117_chickenville.jpg', ''),
(103, '59', 'spa_treatment_lounge.jpeg', ''),
(104, '', 'Sunset.jpg', ''),
(105, '60', 'banner.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_deal_subscriptions`
--

CREATE TABLE IF NOT EXISTS `getdeals_deal_subscriptions` (
  `ds_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `date_added` date NOT NULL,
  PRIMARY KEY (`ds_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `getdeals_deal_subscriptions`
--


-- --------------------------------------------------------

--
-- Table structure for table `getdeals_discussions`
--

CREATE TABLE IF NOT EXISTS `getdeals_discussions` (
  `ds_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `deal_id` bigint(20) NOT NULL,
  `comment` longtext NOT NULL,
  `date_added` datetime NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`ds_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `getdeals_discussions`
--

INSERT INTO `getdeals_discussions` (`ds_id`, `user_id`, `deal_id`, `comment`, `date_added`, `status`) VALUES
(1, 1, 4, 'This is a TEST Comment', '2011-03-15 12:40:36', 1),
(2, 2, 1, 'Comment on Deal ID 1', '2011-03-15 12:40:36', 1),
(5, 1, 2, 'The first moving picture, which depicted a horse running at full gallop, was quickly enhanced by the first special effects, which showed a horse exploding next to a 3-D spaceship. Enjoy advances in film with today\\\\\\''s Groupon: for $10, you get two film tickets at Museum London (a $20 value) on Ridout Street North.', '2011-03-15 07:51:06', 1),
(4, 1, 2, 'A Hockey Musical on March 31, follows seventeen-year-old hockey player Farley (played by Noah Reid) from a sheltered upbringing to a contract with a major hockey team. More upcoming films include The High Cost of Living (May 26), where Isabelle Blais and Zach Braff play characters who cross paths and find life-changing consequences; and Repeaters (June 30), a thriller about three young addicts who live the same events over and over but respond with radically different interpretive dances.', '2011-03-15 07:00:00', 1),
(6, 1, 5, 'This is our first glimpse into Ahab\\\\\\''s despotic givings. He is an unstoppable force prone to anger and face-smashings. Also, it is ironic that Stubbs wants to pray for Ahab because Ahab worships the skeleton of a mermaid he keeps in his quarters. Finally, there is no whale in this chapter, rendering it boring.', '2011-03-16 06:08:01', 1),
(7, 1, 5, 'Everyman should enjoy classic literature, which is why the Groupon Guide invented the Everyman\\\\\\''s Classics study-guide series.', '2011-03-16 06:25:02', 1),
(8, 1, 36, '?? ?????????? ???????????? ?????????? ???????????? ?????????? ?????? ???????????? ?????? ???? ??????????. ???????? ?????? ?????? ?????????????? ???????????? ???? ???????? ???????????????? ?????????? ???? ?????????? ?????? ????. Groupon ?????????? ???????? ???? ???????????? ?????? ???????????? ?????? ???? ?????? ??????????. ???????? ??? ?????????????? ?????????? ???????? ???????? ???? ???????? ?????????? ???????????? ????????????. ???? ?????????????? ?????????????? ?????????? ?????????? ?????????????? ?? ???????????? ???????? ?????????? ???? ?????????????? ???????? ?????????? ???? ???????? ??????????? ??? ?????? ???????????? ???? ???????????? ??????????. ???????? ???????? ???????? ?????????????? ??? ???????? ?????? ???????? ???? ???????????? ???? ?????????? (?????????????????????? ?????????????? ???? ??????????) ???? madeleines ?????? ???????? ?????????????????? ?????????????? ???????? ?????????????? ??? ???????? ?????????????? ???????????????? ?????????????? 10 ???????? ???? 22 ????????. ?????????? ?????? ?????????? ???? ????', '2011-03-24 05:12:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_faqs`
--

CREATE TABLE IF NOT EXISTS `getdeals_faqs` (
  `faq_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `question` varchar(250) NOT NULL,
  `answer` longtext NOT NULL,
  `status` tinyint(2) NOT NULL,
  `date_added` date NOT NULL,
  PRIMARY KEY (`faq_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `getdeals_faqs`
--

INSERT INTO `getdeals_faqs` (`faq_id`, `category_id`, `question`, `answer`, `status`, `date_added`) VALUES
(1, 1, 'Why do you only feature one deal a day?', '<p>When you''re looking for stuff to do, choice can be overwhelming. We focus on one great thing each day and offer it at an unbeatable price to make things simple for you. Hang out with Groupon for a week, and you''ll find something that''s impossible to refuse.</p>\r\n<div id="refHTML">&nbsp;</div>', 1, '2011-08-05'),
(2, 3, 'Do I have to sign up a group of people I know to get the deal?', '<p>Nope - our millions of members make up a big enough group. You''ll probably want to invite people anyway, though&nbsp; ArmaDeals are fun to use with friends, grandparents, and men who wear monocles.<!--Session data--></p>\r\n<div id="refHTML">&nbsp;</div>', 1, '2011-08-05'),
(3, 3, 'I like today''s deal - how do I get it?', '<p>Just click &quot;BUY&quot; before the offer ends at midnight. If the minimum number of people sign up, we''ll charge your card and send you a link to print your ArmaDeal. If not enough people join, no one gets it (and you won''t be charged), so invite your friends to make sure you get the deal!<!--Session data--></p>\r\n<div id="refHTML">&nbsp;</div>', 1, '2011-08-05'),
(6, 1, 'Change Account', '<p>Simply email support@wakadeals.com and provide your old email address, and the new address that you would like...</p>', 1, '2011-08-05'),
(7, 4, 'Can you tell me my seat or aisle number?', '<p><span style="font-size: 14px;"><span style="font-family: arial,helvetica,sans-serif;"><span style="color: rgb(0, 0, 0); background-color: transparent; font-weight: normal; font-style: normal; text-decoration: none; vertical-align: baseline;">Because wakadeals does not issue the tickets ourselves, we can&rsquo;t provide you  with your exact seat assignment. If the seats are listed as being in a  particular section, you are guaranteed to be seated in that section. If  the seats are listed as general admission, you will select your own  seats when you enter the venue.</span></span></span></p>', 1, '2011-08-05'),
(8, 3, 'What happens when I save my billing information?', '<p>When you select &quot;Save this information&quot; at checkout, you''ll be able to use the same credit card for subsequent...When you select &quot;Save this information&quot; at checkout, you''ll be able to use the same credit card for subsequent...</p>', 1, '2011-08-05'),
(9, 3, 'What are bloombucks and how do I use them?', '<p>What are bloombucks? wakadealsbucks are a form of credit to be used at www.wakadeals.com and can be used to purcha..What are bloombucks? bloombucks are a form of credit to be used at www.wakadeals.com and can be used to purcha..</p>', 1, '2011-08-05');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_faqs_category`
--

CREATE TABLE IF NOT EXISTS `getdeals_faqs_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `status` int(11) NOT NULL,
  `date_added` date NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `getdeals_faqs_category`
--

INSERT INTO `getdeals_faqs_category` (`category_id`, `question`, `answer`, `status`, `date_added`) VALUES
(1, 'What is wakadeals?', '<p>wakadeals offers one great experience everyday .......</p>', 1, '2011-08-05'),
(3, 'How do I use wakadeals?', '<p>What happens when I purchase?</p>', 1, '2011-08-05'),
(4, 'Event', '<p>All the events are here...</p>', 1, '2011-08-05');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_featured_businesses`
--

CREATE TABLE IF NOT EXISTS `getdeals_featured_businesses` (
  `fb_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `business_name` varbinary(500) NOT NULL,
  `fname` varbinary(150) NOT NULL,
  `lname` varbinary(150) NOT NULL,
  `email` varbinary(150) NOT NULL,
  `address1` varbinary(1000) NOT NULL,
  `address2` varbinary(500) NOT NULL,
  `city` varbinary(150) NOT NULL,
  `state` varbinary(150) NOT NULL,
  `zip` varbinary(15) NOT NULL,
  `country` varbinary(50) NOT NULL,
  `phone` varbinary(20) NOT NULL,
  `website` varbinary(150) NOT NULL,
  `deal_cat` varbinary(250) NOT NULL,
  `review_links` text NOT NULL,
  `deal_city` varbinary(200) NOT NULL,
  `business_desc` longtext NOT NULL,
  `status` tinyint(2) NOT NULL,
  `date_added` date NOT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fb_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `getdeals_featured_businesses`
--

INSERT INTO `getdeals_featured_businesses` (`fb_id`, `user_id`, `business_name`, `fname`, `lname`, `email`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `phone`, `website`, `deal_cat`, `review_links`, `deal_city`, `business_desc`, `status`, `date_added`, `date_modified`) VALUES
(2, 0, 'Unified Infotech', 'Jyotirmoy', 'Bardhan', 'unified.jyotirmoy@gmail.com', 'GD-126', '', 'Salt Lake', 'West Bengal', '700106', '99', '7878787887', 'http://www.google.com', '2', 'Review Links go here', 'Kolkata', 'This is a Restaurants site', 1, '2011-04-25', '2011-04-25 11:31:47'),
(3, 0, 'Chickenville', 'Johanna', 'Parker', 'joienwobi@chickenville.com', '38, Ogundana Street, Off Allen Ave.', '', 'Victoria Island', 'Lagos', '100011', '156', '8022021134', 'www.chickenville.com', '158', '', 'Victoria Island', 'Have a chicken lunch at good prices.', 1, '2011-05-23', '2011-05-23 20:40:15');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_gateway_setting`
--

CREATE TABLE IF NOT EXISTS `getdeals_gateway_setting` (
  `gateway_id` int(11) NOT NULL AUTO_INCREMENT,
  `api_user` varchar(255) NOT NULL,
  `api_pass` varchar(255) NOT NULL,
  `signature` varchar(255) NOT NULL,
  `type` enum('pro','checkout','merchantpay') NOT NULL,
  `mode` enum('sandbox','live') NOT NULL,
  PRIMARY KEY (`gateway_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `getdeals_gateway_setting`
--

INSERT INTO `getdeals_gateway_setting` (`gateway_id`, `api_user`, `api_pass`, `signature`, `type`, `mode`) VALUES
(1, 'dutta__1313472755_biz_api1.rediffmail.com', '1313472800', 'AymwO-phoFSII7QoA1hiu-OjmedEAruHilw435ACYm113qrtRKZYN2QS', 'pro', 'sandbox'),
(2, 'dutta__1313472755_biz_api1.rediffmail.com', '1313472800', 'AymwO-phoFSII7QoA1hiu-OjmedEAruHilw435ACYm113qrtRKZYN2QS', 'checkout', 'sandbox'),
(3, 'dutta__1313472755_biz_api1.rediffmail.com', '1313472800', 'AymwO-phoFSII7QoA1hiu-OjmedEAruHilw435ACYm113qrtRKZYN2QS ', 'merchantpay', 'sandbox');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_gift_cards`
--

CREATE TABLE IF NOT EXISTS `getdeals_gift_cards` (
  `gc_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `gift_to` varchar(100) NOT NULL,
  `message_text` longtext NOT NULL,
  `gifted_email` varchar(100) NOT NULL,
  `gift_amount` decimal(10,2) NOT NULL,
  `gift_mode` varchar(10) NOT NULL,
  `gift_date` varchar(50) NOT NULL,
  `gift_code` varchar(20) NOT NULL,
  `gift_currency` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `date_added` date NOT NULL,
  PRIMARY KEY (`gc_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `getdeals_gift_cards`
--

INSERT INTO `getdeals_gift_cards` (`gc_id`, `user_id`, `gift_to`, `message_text`, `gifted_email`, `gift_amount`, `gift_mode`, `gift_date`, `gift_code`, `gift_currency`, `status`, `date_added`) VALUES
(1, 1, 'Samriddha Bardhan', 'Gift For My Niece', 'samriddha09@gmail.com', 1999.99, 'friend', '2011-03-15 17:03:22', 'J5JU-QYWO-S1UC', 'USD', '1', '2011-03-15'),
(3, 1, 'Jyotirmoy Bardhan', 'Gifted To Elder Brother', 'unified.jyotirmoy@gmail.com', 1400.00, 'self', '2011-03-14 15:22:03', 'CG77-W3B5-T024', 'EUR', '1', '2011-03-15');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_gift_codes`
--

CREATE TABLE IF NOT EXISTS `getdeals_gift_codes` (
  `gift_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gift_code` varchar(20) NOT NULL,
  `gift_currency` varbinary(10) NOT NULL,
  `gift_amount` decimal(10,2) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `expiry_date` varchar(15) NOT NULL,
  `date_added` varchar(15) NOT NULL,
  PRIMARY KEY (`gift_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `getdeals_gift_codes`
--

INSERT INTO `getdeals_gift_codes` (`gift_id`, `gift_code`, `gift_currency`, `gift_amount`, `status`, `expiry_date`, `date_added`) VALUES
(1, 'J5JU-QYWO-S1UC', 'GBP', 299.99, 1, '23 Mar 2012', '23 Mar 2011'),
(2, 'CG77-W3B5-T024', 'THB', 200.00, 1, '22 Mar 2012', '22 Mar 2011'),
(3, 'O6K6-QQHP-Q3DF', 'DKK', 50.00, 1, '24 Mar 2012', '24 Mar 2011'),
(4, 'Y7HH-WGGV-HOFW', 'EUR', 250.00, 1, '24 Mar 2012', '24 Mar 2011'),
(24, 'PFLK-D67I-KQOO', 'DKK', 43.00, 1, '21 Jul 2012', '21 Jul 2011');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_merchants`
--

CREATE TABLE IF NOT EXISTS `getdeals_merchants` (
  `mid` bigint(20) NOT NULL AUTO_INCREMENT,
  `muser_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `employee_name` varchar(50) NOT NULL,
  `password` varchar(75) NOT NULL,
  `email` varchar(100) NOT NULL,
  `store_name` varchar(50) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(150) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `date_added` date NOT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `getdeals_merchants`
--

INSERT INTO `getdeals_merchants` (`mid`, `muser_id`, `location_id`, `employee_name`, `password`, `email`, `store_name`, `address1`, `city`, `state`, `zip`, `phone`, `status`, `date_added`, `date_modified`) VALUES
(10, 2, 2, 'test2222', 'e10adc3949ba59abbe56e057f20f883e', 'abc@gmail.com', 'store1', 'address 1', 'city test', 'asdfsadfsadf', '543534', '6666666', 1, '2011-09-22', '2011-09-22 00:00:00'),
(9, 2, 3, 'test', 'e10adc3949ba59abbe56e057f20f883e', 'abddd@gmail.com', 'store1', 'address 1', 'city test', 'asdfsadfsadf', '3333333', '2222222', 1, '2011-09-22', '2011-09-22 00:00:00'),
(7, 2, 3, 'test', 'e10adc3949ba59abbe56e057f20f883e', 'unified.jyotirmoy@gmail.com', 'store1', 'address 1', 'city test', 'state state', '3333333', '4634643643', 1, '2011-09-22', '2011-09-22 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_merchant_deals`
--

CREATE TABLE IF NOT EXISTS `getdeals_merchant_deals` (
  `user_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `getdeals_merchant_deals`
--

INSERT INTO `getdeals_merchant_deals` (`user_id`, `deal_id`) VALUES
(2, 11),
(2, 12),
(16, 3),
(16, 2),
(2, 1),
(16, 4),
(16, 5),
(2, 19),
(2, 20),
(2, 21),
(16, 22),
(16, 23),
(16, 24),
(16, 25),
(2, 26),
(0, 27),
(2, 28),
(2, 29),
(2, 30),
(2, 31),
(2, 32),
(2, 33),
(2, 34),
(2, 35),
(2, 36),
(2, 37),
(2, 38),
(2, 0),
(2, 39),
(2, 40),
(2, 41),
(2, 42),
(2, 43),
(2, 44),
(2, 45),
(2, 46),
(2, 47),
(2, 0),
(2, 0),
(2, 49),
(2, 0),
(2, 52),
(2, 53),
(2, 54),
(2, 55),
(2, 56),
(2, 57),
(2, 58),
(2, 59),
(2, 0),
(2, 60);

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_merchant_deal_store_locations`
--

CREATE TABLE IF NOT EXISTS `getdeals_merchant_deal_store_locations` (
  `deal_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `getdeals_merchant_deal_store_locations`
--

INSERT INTO `getdeals_merchant_deal_store_locations` (`deal_id`, `location_id`) VALUES
(32, 2),
(32, 3),
(33, 2),
(34, 2),
(35, 2),
(36, 2),
(37, 2),
(38, 2),
(39, 2),
(40, 2),
(41, 2),
(42, 2),
(43, 2),
(44, 2),
(54, 2),
(53, 3),
(56, 2);

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_merchant_store`
--

CREATE TABLE IF NOT EXISTS `getdeals_merchant_store` (
  `store_id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL,
  `store_name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `primary_location` int(11) NOT NULL,
  `twitterpage` varchar(255) NOT NULL,
  `facebookpage` varchar(255) NOT NULL,
  `business_desc` text NOT NULL,
  `product_recommend` text NOT NULL,
  `experience` text NOT NULL,
  `stand_out` text NOT NULL,
  `why_not_come` text NOT NULL,
  `chq_address1` varchar(300) NOT NULL,
  `chq_address2` varchar(300) NOT NULL,
  `chq_city` varchar(300) NOT NULL,
  `chq_state` varchar(300) NOT NULL,
  `chq_zip` varchar(300) NOT NULL,
  `chq_country` varchar(300) NOT NULL,
  `chq_payable` varchar(300) NOT NULL,
  `date_added` datetime NOT NULL,
  `store_status` int(11) NOT NULL,
  PRIMARY KEY (`store_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `getdeals_merchant_store`
--

INSERT INTO `getdeals_merchant_store` (`store_id`, `merchant_id`, `store_name`, `category_id`, `address1`, `address2`, `city`, `state`, `zip`, `phone`, `website`, `primary_location`, `twitterpage`, `facebookpage`, `business_desc`, `product_recommend`, `experience`, `stand_out`, `why_not_come`, `chq_address1`, `chq_address2`, `chq_city`, `chq_state`, `chq_zip`, `chq_country`, `chq_payable`, `date_added`, `store_status`) VALUES
(1, 16, 'store2', 1, 'address1', '', 'Boston', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 1),
(2, 2, 'store1', 1, 'atlanta st', '', 'Atlanta', 'atlanta', '534534', '555666667777', 'www.website.com', 2, 'www.twitter.com', 'www.facebook.com', 'asdfasdf', 'asdfasdf', 'adfasdf', 'fsadfs', 'sdfsd', 'address 1', 'address 2', 'city test', 'state state', '43543543', 'US', 'sandy', '0000-00-00 00:00:00', 1),
(13, 61, 'test my businesss', 1, 'address 1', 'address 2', 'city test', 'state state', '3333333', '6666666', 'http://www.website.com', 5, 'www.twitter.com', 'www.facebook.com', 'asdf', 'asdf', 'sdfasdf', 'asdf', 'asdfsdaf', 'sdfasdf', 'asdf', 'asdf', 'asdf', 'asdfsda', 'asdfasd', 'dsafsdf', '2011-09-08 07:10:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_merchant_store_categories`
--

CREATE TABLE IF NOT EXISTS `getdeals_merchant_store_categories` (
  `cat_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `date_added` date NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `getdeals_merchant_store_categories`
--

INSERT INTO `getdeals_merchant_store_categories` (`cat_id`, `parent_id`, `cat_name`, `image`, `status`, `date_added`) VALUES
(1, 0, 'Arts', '4e539f2757081060310-130..jpg', 1, '2011-08-23');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_merchant_store_location`
--

CREATE TABLE IF NOT EXISTS `getdeals_merchant_store_location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `longitude` varchar(255) NOT NULL,
  `latitude` varchar(255) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `getdeals_merchant_store_location`
--

INSERT INTO `getdeals_merchant_store_location` (`location_id`, `store_id`, `location_name`, `address1`, `address2`, `city`, `state`, `zip`, `phone`, `longitude`, `latitude`, `added_date`) VALUES
(2, 2, 'test11111', 'address 1', 'address 2', 'city test', 'state test', '3333333', '2222222', '', '', '2011-09-29 07:02:00'),
(3, 2, 'test2', 'addresds', 'sdf', 'sdfsd', 'sssssssssss', '444343', '67453453', '', '', '2011-09-29 07:03:00'),
(5, 13, 'store2', 'address 1', 'address 2', 'city test', 'state test', '777342', '67884', '', '', '2011-09-08 07:39:00'),
(8, 13, 'store1', 'ddgdfg', 'dsfgdfsgdf', 'sdfsd', 'asdfsadfsadf', '43535435', '34643654754', '', '', '2011-09-08 09:43:00');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_merchant_store_profileimage`
--

CREATE TABLE IF NOT EXISTS `getdeals_merchant_store_profileimage` (
  `imgid` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  `tempid` varchar(255) NOT NULL,
  PRIMARY KEY (`imgid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `getdeals_merchant_store_profileimage`
--

INSERT INTO `getdeals_merchant_store_profileimage` (`imgid`, `store_id`, `file`, `tempid`) VALUES
(9, 2, '4e6857e3621281300286736249.jpg', ''),
(10, 11, '4e6863f28fd6b17_9_2009_0_0_0golf.jpg', ''),
(4, 2, '4e5f779c22f38_birds_wallpaper_19.jpg', ''),
(5, 2, '4e5f779f15f602009_los_angeles-016.jpg', ''),
(15, 13, '4e68ab06ae7511._Tarandowah-Golf-Club.jpg_440267_pixels.jpg', ''),
(14, 13, '4e68ab0472e53_birds_wallpaper_19.jpg', ''),
(16, 13, '4e68ab08309b117_9_2009_0_0_0golf.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_merchant_store_sitereview`
--

CREATE TABLE IF NOT EXISTS `getdeals_merchant_store_sitereview` (
  `review_id` bigint(15) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `site` varchar(255) NOT NULL,
  `comment` varchar(300) NOT NULL,
  PRIMARY KEY (`review_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `getdeals_merchant_store_sitereview`
--

INSERT INTO `getdeals_merchant_store_sitereview` (`review_id`, `store_id`, `site`, `comment`) VALUES
(39, 2, 'Metromix', 'http://www.metromix.com'),
(38, 2, 'Google', 'http://www.google.com'),
(42, 13, 'Google', 'www.google.com');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_newsletter`
--

CREATE TABLE IF NOT EXISTS `getdeals_newsletter` (
  `ns_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `city` varchar(150) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `date_added` date NOT NULL,
  PRIMARY KEY (`ns_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `getdeals_newsletter`
--

INSERT INTO `getdeals_newsletter` (`ns_id`, `full_name`, `email`, `city`, `status`, `date_added`) VALUES
(1, 'Jyotirmoy Bardhan', 'unified.jyotirmoy@gmail.com', '', 1, '2011-03-14'),
(2, 'Test', 'aa@aa.com', '', 1, '2011-02-01'),
(3, 'Testing', 'bb@bb.com', '', 1, '2011-02-01');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_orders`
--

CREATE TABLE IF NOT EXISTS `getdeals_orders` (
  `od_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `od_date` date DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  `deal_id` bigint(20) NOT NULL,
  `od_status` enum(' In process','Complete','Cancelled') NOT NULL DEFAULT ' In process',
  `od_memo` varchar(255) NOT NULL DEFAULT '',
  `amount` float NOT NULL,
  `quantity` int(11) NOT NULL,
  `wakadealsbuck_price` float NOT NULL,
  `order_for` varchar(20) NOT NULL,
  `friend_name` varchar(100) NOT NULL,
  `friend_email` varchar(100) NOT NULL,
  `coupon_code` varchar(255) NOT NULL,
  PRIMARY KEY (`od_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `getdeals_orders`
--

INSERT INTO `getdeals_orders` (`od_id`, `od_date`, `user_id`, `deal_id`, `od_status`, `od_memo`, `amount`, `quantity`, `wakadealsbuck_price`, `order_for`, `friend_name`, `friend_email`, `coupon_code`) VALUES
(13, '2011-08-16', 20, 11, 'Complete', '2J730639XT866670W', 2, 1, 0, '', '', '', ''),
(12, '2011-08-16', 20, 11, 'Complete', '37H148008M281171L', 2, 1, 0, '', '', '', ''),
(14, '2011-08-17', 20, 11, 'Complete', '931144973L132214S', 2, 1, 0, '', '', '', '4e4b95d6a49bd-931144973L132214S'),
(15, '2011-08-17', 20, 11, 'Complete', '6NR14151YF377911D', 4, 2, 0, '', '', '', '4e4b99628f63f-6NR14151YF377911D');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_pages`
--

CREATE TABLE IF NOT EXISTS `getdeals_pages` (
  `page_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_cat` varchar(250) NOT NULL,
  `title` varbinary(450) NOT NULL,
  `desc` longtext NOT NULL,
  `status` tinyint(2) NOT NULL,
  `date_added` date NOT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `getdeals_pages`
--

INSERT INTO `getdeals_pages` (`page_id`, `parent_cat`, `title`, `desc`, `status`, `date_added`) VALUES
(1, '', 'About GeeLaza UK', '<div>\r\n<p>We are a online service for group discounts. We only feature the best deals for our customers at a discounted price which is simply unbelievable. Our company model is very simple. we treat our customers just like way we would like to be treated.</p>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div style="float:none; margin: 14px auto 10px auto; width: 664px;"><img alt="" width="664" height="332" src="images/about_img.jpg" /></div>\r\n<div class="clear">&nbsp;</div>\r\n<div>\r\n<p><strong>We simply sell the best and quality stuaff</strong></p>\r\n</div>\r\n<div>\r\n<p>Having a discounted price is only half of the mission, the other half is that the product or service needs to be quality stuff. We have deals all over the UK with unbeatable prices just to make you, the business and us happy. At GeeLaza we are always trying something new to bring the best things to you for a price that everyone is happy about. At GeeLaza we want all our customers to be happy about our deals. everyday, every week. every month. every year. All deals at GeeLaza will last only 1 day unless otherwise stated. We can assure you that you will find fantastic deals everyday live on</p>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div>\r\n<p><strong>Previous Deals </strong></p>\r\n</div>\r\n<div>\r\n<p>Click on &quot;<a href="#">Previous Deals</a>&quot; to see for yourself our great deals that has been bought over hundred times by our great customers. To make sure you don''t miss our great. unbeatable deals just subsribe to our newsletter and check out GeeLaza deals everyday. GeeLaza . waiting to be purchased.</p>\r\n<p>&nbsp;</p>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div>\r\n<p><strong>Here is how you can buy these amazing deals in few simple steps:</strong></p>\r\n</div>\r\n<div>\r\n<p>1. Buy you deal online buy ckick the &quot;<a href="#">BUY THIS DEAL</a>&quot; button and pay for the deal with your preferred payment method.</p>\r\n<p>2. When the payment is completed successfully you will receive an email with your voucher details from GeeLaza. When you have received your voucher then print it and show it to the merchant when you redeem it. Or you can redeem your voucher online using the voucher code depending on the deal offer.</p>\r\n<p>We can only present you these deals but it really depends on deal reaching its tipping point so to make sure you get your deal then spread the word and make the most of your city at amazing discounted prices.</p>\r\n</div>', 1, '2011-11-16'),
(2, '', 'How It Works', '<p>&nbsp;</p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; "><br />\r\n</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; ">wakadeals offers &nbsp;fantastic deals every day with discounts of up to 70% at the best restaurants, Stores and more in Lagos</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; "><br />\r\n</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; ">&nbsp;GET - Check your email, Facebook or Twitter feeds for daily deals on cool bargains. But, you''ll probably be too excited to wait. Once you decide to buy click the link provided and you will be directed to the deal.</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; "><br />\r\n</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; ">BUY - Purchase our daily deals by clicking on the buy button and you will receive a link to your voucher. It''s that simple!</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; "><br />\r\n</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; ">SHARE - Use your social media network (Facebook, Twitter etc) to let friends know about the awesome deal you found. You can share deal info to your friends right from wakadeals.&nbsp;</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; ">Each deal requires a minimum number of friends to get in on the offer before the deal is on, so keep on sharing.</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; "><br />\r\n</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; ">REDEEM - When the deal goes through, we&rsquo;ll send you an e-voucher ( you will be directed to where to go and redeem the e-voucher) and have fun trying something new while saving money. Share your experience online and come back to wakadeals every day for new and amazing bargains.</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; "><br />\r\n</span></p>\r\n<p style="text-align: justify; "><span style="font-family: Verdana; ">Give the gift of wakadeals - &nbsp;You can purchase deals as gifts for friends and family members. You can also buy gift cards to our site and let the recipient choose which great deal they want to get in on.</span></p>\r\n<p>&nbsp;</p>', 1, '2011-05-24');
INSERT INTO `getdeals_pages` (`page_id`, `parent_cat`, `title`, `desc`, `status`, `date_added`) VALUES
(3, '', 'Terms and Conditions', '<div class="box">\r\n<h3>\r\n<p class="MsoNormal">&nbsp;</p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">TERMS AND CO</span><a name="_GoBack"></a><span style="font-family: Verdana; ">NDITIONS</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Welcome to LivingSocial. The following terms and conditions (the &quot;Agreement&quot;) form a binding agreement between you and the LivingSocial company referenced in section &quot;Contracting Party, Choice of Law, Location for Resolving Disputes, Contact Information&quot;, which is sometimes referred to as &ldquo;LivingSocial,&rdquo; &ldquo;we,&rdquo; &ldquo;us&rdquo; or &ldquo;our.&rdquo; Please review the following terms carefully. By using the Site or any LivingSocial Services, you are agreeing to these terms, as well as our Privacy Policy (published at http://www.LivingSocial.com/privacy_policy and incorporated here by reference), and all of these terms will govern your use of the Site and our Services. If you do not agree to these terms, you must cease use of the Site and our Services. The term &quot;you&quot; refers to the person accessing or using the Site or our Services, or the company or organization on whose behalf that person accesses the Site or our Services.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Our Services</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">LivingSocial is an online community for people to organize their interests, browse the collections of their friends, and get recommendations around their interests (the &quot;Services&quot;) through our website located at http://www.LivingSocial.com and other online areas owned or operated by us, such as our Facebook and mobile phone applications (the &quot;Site&quot;). The Services also include the opportunity for you to purchase special Deals (as described below) for the products and services of third party merchants. The Services and Site are collectively referred to here as &quot;LivingSocial.&quot;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Conditional Use of Our Site and Services</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Your permission to use LivingSocial is conditioned upon your agreement that you:</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">are 13 years of age or older, but are 18 years of age or older to purchase any Deal;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">will comply with these Terms of Service;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">will not copy or distribute any part of LivingSocial in any medium without LivingSocial''s prior written authorization;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">will provide accurate information when creating an account or registering for our Services;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">are solely responsible for your User ID and the activity that occurs while signed in to or while using LivingSocial using your User ID;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">will not use LivingSocial to collect any personally identifiable information, including account names, email addresses, or other such information, for commercial purposes;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">will not use the communication systems provided by or contacts made on LivingSocial for any commercial solicitation purposes;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">are solely responsible for your Content submissions, including discussion posts, profile information and links, pictures, and other such content;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">represent that you own or have the necessary licenses, rights, permissions, and consents to use and authorize LivingSocial to use any and all Content submitted by you to LivingSocial in accordance with the licenses granted in this Agreement;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">hereby grant each LivingSocial user, whether using LivingSocial or an application authorized by LivingSocial but developed via a third-party developer, a non-exclusive license to access the Content you submit through LivingSocial and to use, reproduce, distribute, prepare derivative works of, display and perform such Content as permitted through LivingSocial''s functionality and under these Terms of Service;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">will not submit Content that is copyrighted or subject to third party proprietary rights, including privacy, publicity, trade secret, etc., unless you are the owner of such rights or have the appropriate permission from their rightful owner to specifically submit such Content to LivingSocial; and</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">hereby affirm we have the right to determine whether any of your Content submissions are appropriate and comply with these Terms of Service, remove any and/or all of your submissions, and terminate your account with or without prior notice.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Your Account And LivingSocial Profile</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">You will need to register by creating an account with LivingSocial (either by registering directly with us or by allowing a LivingSocial application to connect through your Facebook profile) in order to publish Content on the Site or obtain access to certain Services, including Deals. If you choose to create an account or LivingSocial profile with us, you agree to provide only accurate, complete registration information, and you will keep that information up-to-date if it changes. When you register, you will obtain unique log-in credentials (a &ldquo;User ID&rdquo;). Access to the LivingSocial Site and Services is not authorized by any other person or entity using your User ID and you are responsible for preventing such unauthorized use. Individuals and entities whose privilege to access the Site or use the Services has previously been terminated by LivingSocial may not register for an account, nor may you designate any of those individuals to use your account on your behalf.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">LivingSocial relies on User IDs to know whether users accessing the Site and using our Services are authorized to do so. If someone accesses our Site or Services using a User ID that we&rsquo;ve issued to you, we will rely on that User ID and will assume that access has been made by you. You are solely responsible for any and all access to the Site or use of the Services by persons using your User ID. Please notify us immediately if you become aware that your User ID is being used without authorization.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Non-Confidentiality, Security And Privacy</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">You understand that much of the information that you submit to us (such as postings and invitations) is submitted precisely for the purpose of disclosure in a variety of ways by LivingSocial, and therefore such information is not subject to any confidentiality obligation. Other information, such as credit card information provided in connection with the purchase of a Deal, is maintained with appropriate privacy and security protections. You agree that information provided to us in connection with the purchase of a Deal, other than your credit card information, may be disclosed by us to the LivingSocial Merchant for their commercial purposes including to provision the Deal.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Our Privacy Policy explains how we collect, use and disclose information that pertains to your privacy. The Privacy Policy forms part of our agreement with you and is incorporated in this Agreement by reference. For full details, please refer to our Privacy Policy at http://www.livingsocial.com/privacy-policy.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Any communications between you and LivingSocial, such as email or other correspondence, in which you offer suggestions or comments for improving or modifying our Services will be deemed by us to be non-confidential and non-proprietary, and you agree that such information may be used by us without any limitation whatsoever.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Rules Regarding Information And Other Content</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">When you use the Site, you can publish and obtain access to various kinds of information and materials, all of which we call &quot;Content.&quot; Content also includes information and materials posted to the Site by you. You agree not to revise or obscure Content posted by others (including advertising and promotions authorized by LivingSocial), and you agree not to post or use any Content in any manner that:</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">infringes the copyright, trademark, trade secret, or other intellectual property or proprietary right of others,</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">violates the privacy, publicity, or other rights of third parties,</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">is unlawful, defamatory, discriminatory, libelous, pornographic, obscene, abusive, threatening, harassing, pornographic, hateful, or encourages conduct that would be considered a criminal offense, give rise to civil liability, violate any law, or is otherwise inappropriate, as determined by LivingSocial in its sole discretion, is false or inaccurate, or</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">could damage our company, parent company, sister companies, affiliates, advertisers, or other parties.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Though we strive to enforce these rules with all of our users, you may be exposed through the Site or Services to Content that violates our policies or is otherwise offensive. You may use the Site and Services at your own risk. We may, but are not obligated to, terminate user accounts and/or remove Content from the Site if we determine or suspect that those accounts or Content violate the terms of this Agreement or the applicable agreement with the offending user(s). We take no responsibility for your exposure to Content on the Site whether it violates our content policies or not.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">General Rules Of User Conduct</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">It is our goal to make the use of our Site and Services a good experience for all of our users, so you agree not to do any of the following:</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">conduct or promote any illegal activities while using the Site or Services;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">upload, distribute or print anything that may be harmful to minors;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">attempt to reverse engineer or jeopardize the correct functioning of the Site or Services, or otherwise attempt to derive the source code of the software (including the tools, methods, processes, and infrastructure) that enables or underlies the Site;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">attempt to gain access to secured portions of the Site or Services to which you do not possess access rights;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">upload or transmit any form of virus, worm, Trojan horse, or other malicious code;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">use the Site or Services to generate unsolicited email advertisements or spam;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">use any automatic or manual process to search or harvest information from the Site or Services, or to interfere in any way with the proper functioning of the Site and Services; or impersonate another user.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Links To Third Party Sites</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">We don''t have control over websites that LivingSocial may link to. LivingSocial may contain links to third party websites that are not owned, operated, or controlled by LivingSocial. Therefore, we cannot and do not assume responsibility for the content, privacy policies, or practices of such websites or the companies that own them. Additionally, we cannot and will not censor or edit the content of any third party site. By using LivingSocial you expressly relieve us from any and all liability arising from your use of any third party website.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Deals</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">LivingSocial provides consumers with opportunities to purchase products and services from third party merchants (&quot;Merchants&quot;) with a time limited promotional added value (a &quot;Deal&quot;). Merchants are willing to offer attractive promotionals in order to reach the LivingSocial community.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">1. How It Works</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">By placing an order for a given Deal, you make an offer to purchase the Deal you have selected on the terms, restrictions and conditions associated with the Deal. Once you&rsquo;ve placed your order, you will received a confirmation of the Deal and your credit card will be charged for the amount of the Deal. We will notify you by email when the Voucher (defined below) for the Deal is ready to be used. You are required to create an account in order to purchase any Deal. An account is required so we can collect information to allow you to pay for your Deals and provide you with easy access to print your Deals, view your past purchases, and modify your preferences.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">2. The Voucher</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Each Deal combines two separate portions that make up the Deal: (i) a paid portion equal to the amount your credit card is charged and similar to a paid gift certificate (the &quot;paid portion&quot;); and (ii) at no additional charge to you, a promotional portion for the balance of the value of the Deal if used by the promotional expiration date on the Voucher (the &quot;promotional portion&quot;) (together, the paid and promotional portions of the Deal are presented in a &quot;Voucher&quot;). In the event you redeem your Voucher for less than the full amount stated on the Voucher, your purchase will be allocated first against the paid portion until it has a balance of zero dollars ($0.00) and then against the promotional portion that is remaining.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">3. Expiration Dates</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">The expiration date for a Voucher is as printed on the Voucher.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">If the expiration of the paid value of the Voucher as of the date printed on the Voucher is prohibited under the law of the jurisdiction in which the Merchant is located, then the Voucher shall expire as follows: the promotional portion of the Voucher will expire on the date printed on the Voucher, and the paid portion of the Voucher will expire five (5) years from the date the Voucher is issued, except to the extent applicable law requires that the Merchant extend the period in which the Voucher may be redeemed. The Merchant is obligated to honor the Voucher in compliance with law. If the Merchant refuses to honor the Voucher before the legally permitted expiration date, then LivingSocial will refund the paid portion of your Voucher in the form of a credit for future Deals (what we currently call &ldquo;deal bucks&rdquo;). In order to receive the credit, you must provide the following information in writing to help@livingsocial.com: (a) identification of the Voucher and Merchant with whom you sought to redeem the Voucher, (b) statement of the date, time, and circumstances in which the Merchant refused to redeem the Voucher, and (c) a statement, under penalty of perjury, that the Voucher has never been redeemed with the Merchant.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">4. Deal Bucks</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">&quot;Deal Bucks&quot; are a form of LivingSocial currency that may be applied as a credit towards future LivingSocial purchases. There are three types of Deal Bucks - Paid Deal Bucks, which you may purchase in certain incremental values (either as gift bucks or otherwise), Earned Deal Bucks, which are awarded to you from time to time as loyalty rewards or as customer service deems appropriate, and Promotional Deal Bucks, which are given to certain customers in connection with a specific promotion, contest or sweepstakes. Promotional Deal Bucks expire in accordance with the terms of the particular promotion. Paid and Earned Deal Bucks expire five years after the date of purchase or issuance, except where expiration of Paid Deal Bucks is prohibited by law. Paid Deal Bucks will be applied toward future LivingSocial purchases before Earned Deal Bucks, even if the Earned Deal Bucks expire first. Promotional Deal Bucks however will always be applied first due to their short term. Additionally, all Deal Bucks may only be applied towards purchases that are in the same currency as the Earned, Paid or Promotional Deal Bucks. Deal Bucks are not returnable or refundable for cash, except where required by law. Resale of Deal Bucks is strictly prohibited.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">5. Deal Specific Terms</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Each Deal has specific terms associated with the Deal, which will be presented to you at the time you commit to purchase the particular Deal. Deal specific terms supersede any inconsistent terms in this Agreement, except to the extent such terms are prohibited by applicable law.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">6. Global Terms</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Unless otherwise stated in the Voucher or required by law, the following additional terms apply to all Vouchers:</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">no cash value for any Voucher,</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">no cash back will be issued for partial redemption of the paid portion of a Voucher, except as required by law,</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">no cash back or credit will be issued for partial redemption of the promotional portion of a Voucher,</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">use of a Voucher for alcoholic beverages is at the sole discretion of the Merchant (which may be limited by applicable state or provincial law), unless otherwise noted on the Voucher,</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Vouchers cannot be combined with any other coupons or promotions unless otherwise noted in the Voucher,</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Vouchers cannot be used for taxes, tips, prior balances, shipping or handling, as applicable,</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">neither LivingSocial nor the Merchant is responsible for lost or stolen Vouchers or Voucher reference numbers,</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">duplicate use, sale or trade of a Voucher is prohibited, except as required by law,</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">unless otherwise stated at the time a Voucher is purchased, the Voucher price does not include sales, value added or use taxes, which may be charged to you separately by the Merchant at the time you redeem the Voucher.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">7. Merchant Responsibility</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">To be clear, LivingSocial markets the Deals and acts an as agent in selling the Vouchers on behalf of the Merchants. But the Merchant is the issuer of the Voucher. As issuer of the Voucher, the Merchant shall be fully responsible for any and all injuries, illnesses, damages, claims, liabilities and costs suffered by or in respect of a customer, caused in whole or in part by the Merchant or its products and services, as well as for any unclaimed property liability arising from unredeemed or partially redeemed Vouchers. By purchasing a Deal, a customer acquires the right to print a Voucher issued by the participating Merchant and to use the Voucher according to its terms and the terms of this Agreement. Whether you choose to print and/or redeem the Voucher is within your sole control and at your sole discretion.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">8. Promotions Of The Deal Program</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">From time to time we may offer special promotions, contests and/or sweepstakes intended to provide you an incentive to purchase Deals or to encourage you to get others to do so. The applicable rules will be posted on the Site in or near the description of each such promotion. We reserve the right to interpret these rules in our sole discretion, and you hereby agree to our interpretation.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">9. Products Available For Sale</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">The Site can be accessed from countries around the world. You understand that some or all products or services provided on the Site may not be available for purchase to persons residing in certain jurisdictions or geographic areas. LivingSocial reserves the right, in its sole discretion, to exclude or otherwise limit the provision of a Voucher for any product or service to a person residing in any jurisdiction or geographical area. LivingSocial does not represent or warrant that any product or service promoted on the Site will be available for purchase by any particular person.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">10. Refunds</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">LivingSocial will provide a refund of the purchase price paid by you for any Deal within five days after the purchase of a Voucher, provided that the Voucher has not yet been redeemed. After five days, we do not provide refunds except that we will provide a refund if you are unable to redeem a Voucher before the applicable expiration of the Voucher because the relevant Merchant has gone out of business.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">11. Playing Nicely</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Some of the Deals are provided for a limited number of purchasers or a limited number of purchases, as specified for the particular Deal. Any attempt by a purchaser to obtain more than the permitted number of Vouchers specified for a particular Deal by using multiple or different identities, credit cards, forms, registrations, addresses or any other method will void that person''s purchases. LivingSocial will be the arbiter, in its discretion, as to whether purchase characteristics indicate a violation of these rules.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Termination</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">We may change or discontinue the Site or any of the Services at any time without prior notice. We reserve the right to terminate this Agreement at our election and for any reason, without prior notice, and this Agreement will automatically terminate in the event that you violate any of the terms and conditions set forth below. In the event of any termination, you will immediately cease access to the Site and Services. Any Voucher issued prior to termination will be honored according to its terms and the terms of this Agreement specifically applicable to such Voucher.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Disclaimers of Warranty</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">We provide the Site and Services &quot;as is&quot;, &quot;with all faults&quot; and &quot;as available.&quot; We and our suppliers and Merchants make no express warranties or guarantees about the Site, Services or Deals. TO THE MAXIMUM EXTENT PERMITTED BY LAW, WE AND OUR OFFICERS, DIRECTORS, AGENTS, VENDORS, AND MERCHANTS DISCLAIM IMPLIED WARRANTIES THAT THE SITE AND SERIVCES ARE MERCHANTABLE, OF SATISFACTORY QUALITY, ACCURATE, TIMELY, FIT FOR A PARTICULAR PURPOSE OR NEED, OR NON-INFRINGING. WE DO NOT GUARANTEE THAT LIVINGSOCIAL WILL MEET YOUR REQUIREMENTS, IS ERROR-FREE, RELIABLE, WITHOUT INTERRUPTION OR AVAILABLE AT ALL TIMES. WE DO NOT GUARANTEE THAT THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF LIVINGSOCIAL, INCLUDING ANY SERVICES OR DEALS, WILL BE EFFECTIVE, RELIABLE, ACCURATE OR MEET YOUR REQUIREMENTS. WE MAKE NO WARRANTIES AS TO PRIVACY AND SECURITY OTHER THAN AS EXPRESSLY STATED IN THE PRIVACY POLICY. WE DO NOT GUARANTEE THAT YOU WILL BE ABLE TO ACCESS OR USE THE SITE OR SERVICES AT TIMES OR LOCATIONS OF YOUR CHOOSING. NO ORAL OR WRITTEN INFORMATION OR ADVICE GIVEN BY A LIVINGSOCIAL REPRESENTATIVE SHALL CREATE A WARRANTY. You may have additional consumer rights under your local laws that this contract cannot change.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Limitations of Liability</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">YOUR SOLE AND EXCLUSIVE REMEDY FOR ANY DISPUTE WITH US IS TO DISCONTINUE YOUR USE OF LIVINGSOCIAL. IN NO EVENT SHALL OUR LIABILITY, OR THE LIABILITY OF OUR AFFILIATES, OFFICERS, DIRECTORS, AGENTS, VENDORS, OR MERCHANTS, FOR ANY AND ALL CLAIMS RELATING TO THE USE OF THE SITE AND SERVICES EXCEED THE TOTAL AMOUNT OF FEES THAT YOU PAID US DURING THE PREVIOUS ONE-YEAR PERIOD FOR THE SPECIFIC SERVICE AT ISSUE. WE, OUR AFFILIATES, OFFICERS, DIRECTORS, AGENTS, VENDORS, AND MERCHANTS, SHALL NOT BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL OR EXEMPLARY DAMAGES ARISING FROM YOUR USE OF, INABILITY TO USE, OR RELIANCE UPON THE SITE AND SERVICES. THESE EXCLUSIONS APPLY TO ANY CLAIMS FOR LOST PROFITS, LOST DATA, LOSS OF GOODWILL, WORK STOPPAGE, COMPUTER FAILURE OR MALFUNCTION, OR ANY OTHER COMMERCIAL DAMAGES OR LOSSES, EVEN IF WE KNEW OR SHOULD HAVE KNOWN OF THE POSSIBILITY OF SUCH DAMAGES. IF ANY JURISDICTION DOES NOT ALLOW THE EXCLUSION OR THE LIMITATION OF LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES, IN SUCH JURISDICTION, OUR LIABILITY, AND THE LIABILITY OF OUR AFFILIATES, OFFICERS, DIRECTORS, AGENTS, VENDORS, AND MERCHANTS, SHALL BE LIMITED TO THE EXTENT PERMITTED BY LAW.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Indemnity</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">You agree to defend, indemnify and hold harmless LivingSocial, its parent company, officers, directors, employees and agents, from and against any and all claims, damages, obligations, losses, liabilities, costs or debt, and expenses (including but not limited to reasonable attorney''s fees) arising from: (i) your use of and access to LivingSocial; (ii) your violation of any term of these Terms of Service; (iii) your violation of any third party right, including without limitation any copyright, property, or privacy right; or (iv) any claim that any Content submitted by you causes damage to a third party. This defense and indemnification obligation will survive these Terms of Service and your use of LivingSocial.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><o:p><span style="font-family: Verdana; ">&nbsp;</span></o:p></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Reservation of Rights and Release</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">LivingSocial reserves the right, but has no obligation, to monitor, or take any action LivingSocial deems appropriate regarding disputes that you may have with other customers of ours or any Merchants. To the extent the law permits, you release us from any claims or liability related to any Content posted on the Site and from any claims related to the conduct of any other customers of ours or any Merchants. You hereby waive California Civil Code Section 1542 (if you are a California resident), and any similar provision in any other jurisdiction (if you are a resident of such jurisdiction), which states: &quot;A general release does not extend to claims which the creditor does not know or suspect to exist in his favor at the time of executing the release, which, if known by him must have materially affected his settlement with the debtor.&quot;</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Intellectual Property</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">You acknowledge and agree that we and our licensors retain ownership of all intellectual property rights of any kind related to the Site and Services, including applicable copyrights, trademarks and other proprietary rights. We are not granting any license to you under any of those intellectual property rights by virtue of this Agreement, except for the limited right to use the Site and Services in accordance with this Agreement. &ldquo;LivingSocial&rdquo; is our trademark. Other product and company names that are mentioned on the Site or provided as part of the Services may be trademarks of their respective owners. We reserve all rights that are not expressly granted to you in this Agreement.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">The Content on LivingSocial, excluding all intellectual property of other sites obtained by way of API and linking and Content posted by our customers, is owned by LivingSocial. This includes, without limitation, the text, software, scripts, graphics, photos, sounds, interactive features and the trademarks, service marks and logos contained therein (&quot;Marks&quot;). The Marks are owned or licensed to LivingSocial, subject to copyright and other intellectual property rights under United States law, the law of the jurisdiction where you reside, and and international conventions. Content provided by LivingSocial is provided to you &ldquo;AS IS&rdquo; for your information and personal use only and may not be used, copied, reproduced, modified, distributed, transmitted, broadcast, displayed, sold, licensed, or otherwise exploited for any other purposes whatsoever without the prior written consent of the respective owners. We reserve all rights not expressly granted in and to the Site and Services.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">As between you and us, you retain any intellectual property rights in any copyrighted materials and trademarks that are contained in Content that you post to the Site. You grant us an irrevocable, perpetual, non-exclusive, royalty-free, fully paid, worldwide license, with rights to sublicense through multiple levels of sublicensees, to reproduce, make derivative works of, translate, distribute, publicly perform and publicly display in any form or medium, whether now known or later developed, make, use, sell, import, offer for sale, otherwise commercially exploit and exercise any and all such rights, under any and all of your intellectual property rights related to the Content in any manner we choose. If you have any rights to the Content that cannot be licensed to us (such as moral rights in some countries), you unconditionally and irrevocably waive the enforcement of such rights, and all claims and causes of action of any kind against us or related to our customers and partners anywhere in the world, with respect to such rights.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Copyright Notice</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">We respect the intellectual property of others, and we ask you to do the same. If you are a copyright owner or an owner''s agent and find Content that infringes upon your copyrights, you may submit a notification according to the Digital Millennium Copyright Act. To do so, please provide our Copyright Agent with the following information (see 17 U.S.C 512(c)(3) for further detail) in writing: (1) A physical or electronic signature of a person authorized to act on behalf of the owner of an exclusive right that is allegedly infringed; (2) Identification of the copyrighted work claimed to have been infringed, or, if multiple copyrighted works at a single online site are covered by a single notification, a representative list of such works at that site; (3) Identification of the material that is claimed to be infringing or to be the subject of infringing activity and that is to be removed or access to which is to be disabled and information reasonably sufficient to permit the service provider to locate the material; (4) Information reasonably sufficient to permit the service provider to contact you, such as an address, telephone number, and, if available, an electronic mail; (5) A statement that you have a good faith belief that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or the law; and (6) A statement that the information in the notification is accurate, and under penalty of perjury, that you are authorized to act on behalf of the owner of an exclusive right that is allegedly infringed. LivingSocial''s designated Copyright Agent to receive notifications of claimed infringement can be reached at help@livingsocial.com. You acknowledge that if you fail to comply with all of the requirements of this Section, your DMCA notice may not be valid.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Electronic Communications</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">The communications between you and LivingSocial use electronic means, whether you visit the Site or send us emails, or whether LivingSocial posts notices on the Site or communicates with you via email. For contractual purposes, you (a) consent to receive communications from LivingSocial in an electronic form; and (b) agree that all terms and conditions, agreements, notices, disclosures, and other communications that LivingSocial provides to you electronically satisfy any legal requirement that such communications would satisfy if it were in writing. The foregoing does not affect your non-waivable rights.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Entire Agreement, Changes to this Agreement and Waivers</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">These Terms of Service, together with the Privacy Policy at http://www.LivingSocial.com/privacy_policy and any other legal notices published by LivingSocial on the Site or any Deal Voucher, shall constitute the entire agreement between you and LivingSocial concerning LivingSocial. We may change the terms of this Agreement from time to time on a going-forward basis, and any such modifications become effective immediately upon being posted to the Site. It is your sole responsibility to check the Site from time to time to view any such changes in the Agreement. If you do not agree to any changes, if and when such changes may be made to the Agreement, you must cease use of the Site and Services. Your use of the Site and Services after any modifications to the Agreement indicates that you agree to such modified Agreement. Any changes to this Agreement (other than as set forth in this paragraph) or waiver of LivingSocial&rsquo;s rights hereunder shall not be valid or effective except in a written agreement bearing the physical signature of an officer of LivingSocial. No purported waiver or modification of this Agreement by LivingSocial via telephonic or email communications shall be valid.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Contracting Party, Choice of Law, Location for Resolving Disputes, Contact Information</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">This Agreement is between you and the LivingSocial entity for your country in which you reside. The identity of the LivingSocial entity for your country, the choice of law, the location for resolving disputes with LivingSocial, and our contact information is specified below.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">England &amp; Wales. If you reside in England or Wales, then you are contracting with LivingSocial Limited, a company registered in England and Wales with registration number 07227708 and with registered offices at 20 Hanover Square, London W1S 1JY; help@livingsocial.com; 0 800 014 8431. The laws of England govern the interpretation of this Agreement and any disputes arising in connection with it, regardless of conflict of laws principles. Any claim or dispute between you and LivingSocial that arises out of or relates to this Agreement shall be decided exclusively by a court of competent jurisdiction located in London, England.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Ireland. If you reside in Ireland, then you are contracting with LivingSocial Europe Limited, a company registered in Ireland with registration number 487251 and with registered offices at South Bank House, 6th Floor, Barrow Street, Dublin 4; help@livingsocial.com; phone: +353 1 234 2557, fax: +353-1-234-2400. The laws of Ireland govern the interpretation of this Agreement and any disputes arising in connection with it, regardless of conflict of laws principles. Any claim or dispute between you and LivingSocial that arises out of or relates to this Agreement shall be decided exclusively by a court of competent jurisdiction located in Dublin, Ireland.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Canada. If you reside in Canada, then you are contracting with LivingSocial Canada Enterprises, Inc. Communications may be directed to: LivingSocial, 829 7th Street, NW, Washington, DC 20001; help@livingsocial.com; 877-521-4191. The laws of British Columbia, and the laws of Canada applicable therein, govern the interpretation of this Agreement and any disputes arising in connection with it, regardless of conflict of laws principles. Any claim or dispute between you and LivingSocial that arises out of or relates to this Agreement shall be decided exclusively by a court of competent jurisdiction located in Vancouver, British Columbia.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">Australia If you reside in Australia, communications may be directed to: LivingSocial, Suite 204, Level 2 24-26 Falcon Street, Crows Nest Village NSW, 2065; aushelp@livingsocial.com; +61 2 8005 1915. The laws of New South Wales govern the interpretation of this Agreement and any disputes arising in connection with it, regardless of conflict of laws principles. Any claim or dispute between you and LivingSocial that arises out of or relates to this Agreement shall be decided exclusively by a court of competent jurisdiction located in New South Wales. Payments are processed by LivingSocial Limited, a company registered in England and Wales.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">New Zealand If you reside in New Zealand, communications may be directed to: LivingSocial, P.O. Box 147299, Ponsonby, Auckland, 1144; aushelp@livingsocial.com; +61 2 8005 1915. The laws of New Zealand govern the interpretation of this Agreement and any disputes arising in connection with it, regardless of conflict of laws principles. Any claim or dispute between you and LivingSocial that arises out of or relates to this Agreement shall be decided exclusively by a court of competent jurisdiction located in New Zealand. Payments are processed by LivingSocial Limited, a company registered in England and Wales.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">United States &amp; rest of world. If you reside in the United States or other countries not specifically identified above, then you are contracting with Hungry Machine, Inc. Communications may be directed to: LivingSocial, 829 7th Street, NW, Washington, DC 20001; help@livingsocial.com; 877-521-4191. The laws of the District Columbia govern the interpretation of this Agreement and any disputes arising in connection with it, regardless of conflict of laws principles. Any claim or dispute between you and LivingSocial that arises out of or relates to this Agreement shall be decided exclusively by a court of competent jurisdiction located in the District of Columbia.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">General Terms</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">You and we are independent contractors, and nothing in this Agreement creates a partnership, employment relationship or agency. There are no third-party beneficiaries of this Agreement. You may not assign this Agreement or your rights and obligations hereunder, in whole or in part, to any third party without our prior written consent, and any attempt by you to do so will be invalid. Should any part of this Agreement be held invalid or unenforceable, that portion will be construed consistent with applicable law and the remaining portions will remain in full force and effect. Our failure to enforce any provision of this Agreement will not be considered a waiver of the right to enforce such provision. Our rights under this Agreement will survive any termination of this Agreement.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">YOU AND LIVINGSOCIAL AGREE THAT ANY CAUSE OF ACTION ARISING OUT OF OR RELATED TO LIVINGSOCIAL MUST COMMENCE WITHIN ONE (1) YEAR AFTER THE CAUSE OF ACTION ACCRUES. OTHERWISE, SUCH CAUSE OF ACTION IS PERMANENTLY BARRED.</span></p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">You represent that you are legally able to accept these Terms of Service. You affirm that you are either more than 18 years of age, or an emancipated minor, or possess legal parental or guardian consent, and are fully able and competent to enter into the terms, conditions, obligations, affirmations, representations, and warranties set forth in this Agreement, and to abide by and comply with this Agreement. And as stated in the Conditional Use of Our Site and Service, above, you affirm that you are, in any case, 13 years of age or older. If you aren''t, you must please cease use of LivingSocial.</span></p>\r\n<p style="text-align: justify; ">&nbsp;</p>\r\n<p class="MsoNormal" style="text-align: justify; "><span style="font-family: Verdana; ">&nbsp;</span></p>\r\n</h3>\r\n</div>', 1, '2011-11-16');
INSERT INTO `getdeals_pages` (`page_id`, `parent_cat`, `title`, `desc`, `status`, `date_added`) VALUES
(4, '', 'Privacy Policy', '<p>This wakadeals privacy policy (the &quot;Privacy Policy&quot;) is intended to inform you of our policies and practices regarding the collection, use and disclosure of any information you submit to us through wakadeals. This includes &quot;Personal Information,&quot; which is information about you that is personally identifiable such as your name, e-mail address, user ID number, and other non-public information that is associated with the foregoing, as well as &quot;Anonymous Information,&quot; which is information that is not associated with or linked to your Personal Information and does not permit the identification of individual persons.</p>\r\n<p class="MsoNormal"><o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p><strong>User Consent</strong><o:p></o:p></p>\r\n<p class="MsoNormal">By accessing or otherwise using wakadeals, you agree to the terms and conditions of this Privacy Policy, which is incorporated into and forms a part of the wakadeals terms of service (set forth on http://www.wakadeals.com/terms). You expressly consent to the processing of your Personal Information and Anonymous Information according to this Privacy Policy.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p class="MsoNormal">Your Personal Information may be processed and stored in other countries (including the United States) where laws regarding processing of Personal Information may be less stringent than the laws in your country. Your Personal Information will not, however, be used or disclosed for purposes for which you have not given consent or which are not permitted under applicable law.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p><strong>Regarding Children</strong><o:p></o:p></p>\r\n<p class="MsoNormal">Children under the age of 13 are not permitted to use wakadeals and we do not intentionally collect or maintain Personal Information from those who are under 13 years old. Protecting the privacy of children is very important to us. Thus, if we obtain actual knowledge that a user is under 13, we will take steps to remove that user''s Personal Information permanently from our databases. We recommend that children between the ages of 13 and 18 obtain their parent&rsquo;s permission before submitting information over the internet. By using wakadeals, you are representing that you are at least 18 years old, or that you are at least 13 years old and have a parent&rsquo;s or guardian&rsquo;s permission to use wakadeals.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p><strong>Collection of Information</strong><o:p></o:p></p>\r\n<p class="MsoNormal"><strong>Personal Information That You Provide</strong><o:p></o:p></p>\r\n<p class="MsoNormal">In general, we collect Personal Information that you submit to us voluntarily through wakadeals. We also collect information that you submit in the process of creating or editing your account and user profile on wakadeals. For example, our registration and login process requires you to provide us with your name, valid email address and password of your choice. When you personalize your profile and use the features of wakadeals, we will collect any information you voluntarily provide, and we may also request optional information to support your use of wakadeals, such as your year of birth, gender and other demographic information. We collect information in the form of the content that you submit during your use of wakadeals, such as photos, reviews, ratings and other information you choose to submit. We may also collect information about you and your friends who use wakadeals, from any social network you may have connected from, in order to provide you with a more personalized experience. For instance, we may collect your user ID or profile information that you have permitted to be displayed through wakadeals in order to display you as a friend or in association with your profile and collections. When you purchase a Deal, you will need to submit your credit card or other payment information so that our service providers can process your payment for the Deal. When you sign up for, or win, any contests, sweepstakes, or other activities that we make available on wakadeals, we will collect the information designated along with such activity, which may include your contact information such as your address and phone number. If you choose to sign up to receive information about products or services that may be of interest to you, we will collect your email address and other related information. Additionally, we collect any information that you voluntarily enter, including Personal Information, into any postings, comments, or forums within the wakadeals community.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p><strong>Personal Information From Other Sources</strong><o:p></o:p></p>\r\n<p class="MsoNormal">We may receive Personal Information about you from other sources with which you have registered, companies who we have partnered with (collectively, &quot;Partners&quot;) or other third parties. We may associate this information with the other Personal Information we have collected about you.<o:p></o:p></p>\r\n<p class="MsoNormal"><strong>E-Mail And E-Mail Addresses</strong><o:p></o:p></p>\r\n<p class="MsoNormal">If you send an e-mail to us, or fill out our &quot;Feedback&quot; form through wakadeals, we will collect your e-mail address and the full content of your e-mail, including attached files, and other information you provide. We may use and display your full name and email address when you send an email notification to a friend through wakadeals or the social network from which you have connected to wakadeals (such as in an invitation, or when sharing your content). Additionally, we use your email address to contact you on behalf of your friends (such as when someone sends you a personal message) or notifications from a social network or other website with whom you have registered to receive such notifications. We may use this e-mail address to contact you, for things such as notifications of limited edition shop sales and other related information. You may indicate your preference to stop receiving further promotional communications as further detailed below.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p><strong>Information Collected Via Technology</strong><o:p></o:p></p>\r\n<p class="MsoNormal">As you use wakadeals, certain information may also be passively collected and stored on our or our service providers&rsquo; server logs, including your Internet protocol address, browser type, and operating system. We also use Cookies and navigational data like Uniform Resource Locators (URL) to gather information regarding the date and time of your visit and the solutions and information for which you searched and viewed, or on which of the advertisements displayed on wakadeals you clicked. This type of information is collected to make wakadeals and solutions more useful to you and to tailor the experience with wakadeals to meet your special interests and needs.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>An &quot;Internet protocol address&quot; or &quot;IP Address&quot; is a number that is automatically assigned to your computer when you use the Internet. In some cases your IP Address stays the same from browser session to browser session; but if you use a consumer internet access provider, your IP Address probably varies from session to session. For example, we, or our service providers, may track your IP Address when you access wakadeals to assist with ad targeting.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>&quot;Cookies&quot; are small pieces of information that a website sends to your computer&rsquo;s hard drive while you are viewing a website. We may use both session Cookies (which expire once you close your web browser) and persistent Cookies (which stay on your computer until you delete them) to provide you with a more personal and interactive experience with wakadeals. Persistent Cookies can be removed by following your Internet browser help file directions. In order to use our services offered through wakadeals, your web browser must accept Cookies. If you choose to disable Cookies, some aspects of wakadeals may not work properly, and you may not be able to receive our services.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>We may also enable advertisers and ad servers to promote third-party products and/or services by placing advertisements on wakadeals. These advertisers and ad servers may use Cookies and/or &quot;Web Beacons&quot; (which are usually small, transparent graphic images) in order to monitor information related to served advertisements. Clicking on such advertisements will direct you to the website of a third-party and the advertiser. This Privacy Policy does not cover the privacy practices of any advertisers or ad servers.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p><strong>Use and Disclosure of Information</strong><o:p></o:p></p>\r\n<p class="MsoNormal">Except as otherwise stated in this Privacy Policy, we do not sell, trade, rent, or otherwise share for marketing purposes the Personal Information that we collect with third parties, unless you ask or authorize us to do so.<o:p></o:p></p>\r\n<p class="MsoNormal">In general, Personal Information you submit to us is used by us to provide you access to wakadeals, to improve wakadeals, to better tailor the features, performance, and support of wakadeals and to offer you additional information, opportunities, promotions and functionality from us, our partners or our advertisers at your request. Additionally, we do share your content preferences and other information with the social network with which you have connected to wakadeals, along with those companies and persons you have asked us to share your information with.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>We may provide your Personal Information to third-party service providers who work on behalf of or with us to provide some of the services and features of wakadeals and to help us communicate with you. Examples of such services include sending email, analyzing data, providing marketing assistance, processing payments (including credit card payments), and providing customer service. We require our third-party service providers to promise not to use such information except as necessary to provide the relevant services to us. We may share some or all of your Personal Information (other than credit card information) with Merchants whose Deals you have purchased for their commercial purposes and to provision the Deal... If you do not want us to use or disclose Personal Information collected about you in the manner identified in this Privacy Policy, you may not use wakadeals.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>Additionally, we may create Anonymous Information records from Personal Information by excluding information (such as your name) that would otherwise make the Anonymous Information personally identifiable to you. Generally, we aggregate this information and use it in statistical analysis to help us analyze patterns in the use of wakadeals. This Privacy Policy does not limit our use or disclosure of any Anonymous Information in any way, and we reserve the right to use and disclose Anonymous Information to our partners, advertisers and other third parties in our discretion.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>We may share some or all of your Personal Information with wakadeals affiliated companies that are under a common control, in which case we will require them to honor this Privacy Policy.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>In the event we go through a business transition such as a merger, acquisition by another company, or sale of all or a portion of our assets, your Personal Information may be among the assets transferred. You acknowledge that such transfers may occur and are permitted by this Privacy Policy, and that any acquirer of ours or that acquirer&rsquo;s assets may continue to process your Personal Information as set forth in this Privacy Policy.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>We may disclose your Personal Information if we believe in good faith that such disclosure is necessary to (a) comply with relevant laws or to respond to subpoenas or warrants served on us; or (b) to protect and defend our rights or property, you, or third parties. You hereby consent to us sharing your Personal Information under the circumstances described herein.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p><strong>&nbsp;</strong></o:p><strong>The Ability Of Others To View Your Information</strong><o:p></o:p></p>\r\n<p class="MsoNormal">Helping you to protect your information is a vital part of our mission. It is up to you to make sure you are comfortable with the information you choose to provide us and the information you choose to publish. You understand that when you use wakadeals, certain information you post or provide through wakadeals, such as your name, profile, comments, collections and reviews, may be shared with other users and posted on publicly available portions of wakadeals, including without limitation, social media applications and other public fora in which you choose to participate. Please keep in mind that if you choose to disclose Personal Information when posting comments or other information or content through wakadeals, this information may become publicly available and may be collected and used by others, including people outside the wakadeals community. We will not have any obligations with respect to any information that you post to parts of wakadeals available to others, and recommend that you use caution when giving out personal information to others through social media networks or otherwise.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p class="MsoNormal"><strong>Third Party Sites And Advertising</strong><o:p></o:p></p>\r\n<p class="MsoNormal">wakadeals may contain links to other websites. Please be aware that we are not responsible for the privacy practices or the content of such other websites. We encourage our users to read the privacy statements of each and every website they visit. This Privacy Policy applies solely to information collected by us through wakadeals and does not apply to these third-party websites. The ability to access information of third-parties from wakadeals, or links to other websites or locations, is for your convenience and does not signify our endorsement of such third-parties, their products, their services, other websites, locations or their content.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p><strong>Your Choices Regarding Your Personal Information</strong><o:p></o:p></p>\r\n<p class="MsoNormal">We offer you choices regarding the collection, use, and sharing of your Personal Information. You have a right at any time to stop us from contacting you for marketing purposes. When you receive promotional communications from us, you may indicate a preference to stop receiving further promotional communications from us and you will have the opportunity to &quot;opt-out&quot; by following the unsubscribe instructions provided in the promotional e-mail you receive or by contacting us directly at help@wakadeals.com.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>Despite your indicated email marketing preferences, we may send you administrative emails regarding wakadeals, including, for example, administrative and transactional confirmations, and notices of updates to our Privacy Policy if we choose to provide such notices to you in this manner.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>You have the right to request a copy of the Personal Information that we hold about you. If you would like a copy of some or all of your Personal Information, please contact us at help@wakadeals.com. We may charge a reasonable fee for this service. We want to make sure that your information is accurate and up-to-date. You may ask us to correct or remove information which you think is inaccurate. You may change any of your profile information by editing it in the profile settings page.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p><strong>&nbsp;</strong></o:p><strong>Feedback</strong><o:p></o:p></p>\r\n<p class="MsoNormal">If you provide feedback to us, we may use and disclose such feedback for any purpose, provided we do not associate such feedback with your Personal Information. We will collect any information contained in such feedback and will treat the Personal Information in it in accordance with this Privacy Policy. You agree that any such comments and any email we receive becomes our property. We may use feedback for marketing purposes or to add to or modify our services without paying any royalties or other compensation to you.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p><strong>Security</strong><o:p></o:p></p>\r\n<p class="MsoNormal">We are committed to protecting the security of your Personal Information. We use a variety of industry-standard security technologies and procedures to help protect your Personal Information from unauthorized access, use, or disclosure. Even though we have taken significant steps to protect your Personal Information, no company, including us, can fully eliminate security risks associated with Personal Information.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p><strong>&nbsp;</strong></o:p><strong>Contact And Revisions</strong><o:p></o:p></p>\r\n<p class="MsoNormal">If you have questions or concerns about our Privacy Policy, please contact us at: help@wakadeals.com.<o:p></o:p></p>\r\n<p class="MsoNormal"><o:p>&nbsp;</o:p>This Privacy Policy is subject to occasional revision at our discretion, and if we make any substantial changes in the way we use your Personal Information, we will post an alert on this page or may otherwise post an alert on the wakadeals blog available at http://blog.wakadeals.com. If you object to any such changes, you must cease using wakadeals. Continued use of wakadeals following notice of any such changes shall indicate your acknowledgement of such changes and agreement to be bound by the terms and conditions of such changes.<o:p></o:p></p>', 1, '2011-05-24'),
(5, '', 'Got a idea for GeeLaza?', '<p>Fusce gravida dui luctus ante adipiscing bibendum. Fusce congue, nunc ac vehicula tincidunt</p>', 1, '2011-11-16'),
(6, '', 'Why use GeeLaza?', '<p><b>GetDeals</b> features the best restaurants, spas, hotels, and other local experiences to our members.</p>\r\n<p>We  partner with exceptional businesses to create offers that will entice  our members to experience new venues and services. Currently, we serve  the following markets:</p>', 1, '2011-11-16'),
(7, '', 'Affiliate program', '<ol>\r\n    <li>An exclusive trial offer for our members\r\n    <ul>\r\n        <li>Limited opportunity to pre-buy your services at an exclusive price</li>\r\n        <li>Delivered to our members via email</li>\r\n    </ul>\r\n    </li>\r\n    <li>A lasting editorial feature on wakadeals.com\r\n    <ul>\r\n        <li>Rich photographic presentation of your venue</li>\r\n        <li>Write-up by our expert editorial team</li>\r\n        <li>Remains on our site after your trial offer ends, without any of the trial offer details</li>\r\n    </ul>\r\n    </li>\r\n</ol>', 1, '2011-11-16'),
(8, '', 'Benefits', '<div style="margin-top: 20px;" class="bodyboxcontent">\r\n<h3>Partnering with wakadeals can benefit your business in many ways:</h3>\r\n<ul>\r\n    <li>Revenue up front</li>\r\n    <li>More business during off-peak times</li>\r\n    <li>Exposure to our proprietary list of primarily affluent women ages 30 - 50</li>\r\n    <li>Entice new customers to:\r\n    <ul>\r\n        <li>Experience your venue</li>\r\n        <li>Tell their friends and family about your services</li>\r\n        <li>Become repeat clientele</li>\r\n    </ul>\r\n    </li>\r\n</ul>\r\n</div>', 1, '2011-08-04'),
(9, '', 'Our Members', '<div style="margin-top: 20px;" class="bodyboxcontent">\r\n<h3><b>wakadeals</b>''s Members are:</h3>\r\n<ul>\r\n    <li><span class="linetitle">Mature and Affluent:</span> <b>wakadeals </b>members are primarily women in their 30s, 40s, and 50s from affluent zipcodes.</li>\r\n    <li><span class="linetitle">Decisive Spenders:</span> Our members are not afraid to spend.  The average price point of <b>wakadeals</b> deals is above $75.</li>\r\n    <li><span class="linetitle">Social Butterflies:</span> When <b>wakadeals </b>members find a concept or business they are excited about, they spread the word to their friends.  75% of <b>wakadeals </b>purchasers learned about the site from a friend.</li>\r\n    <li><span class="linetitle">Not Coupon Chasers:</span>  Our goal is to bring you new permanent customers, not serial bargain  hunters.   We acquire members through carefully targeted ads and  word-of-mouth referrals from existing subscribers.</li>\r\n</ul>\r\n</div>\r\n<p>&nbsp;</p>', 1, '2011-08-04'),
(10, '', 'Suggest a business', '<ol>\r\n    <li>Our editors will work with you to create an offer.\r\n    <ul>\r\n        <li>You tell us more about your business (busier vs. slower times, capacity constraints, etc.)</li>\r\n        <li>We work with you to develop a compelling offer that will excite our members and accommodate your needs</li>\r\n        <li>Our editorial team compiles the feature and we email it out to our members</li>\r\n    </ul>\r\n    </li>\r\n    <li>New customers purchase your offer online, right away\r\n    <ul>\r\n        <li>Your offer is available for a limited time; on average 2 days</li>\r\n        <li>We process online payments, provide live customer support, and send you a check after the offer ends</li>\r\n    </ul>\r\n    </li>\r\n    <li>New Customers in your door\r\n    <ul>\r\n        <li><b>wakadeals</b> purchasers visit and experience your venue in person</li>\r\n        <li>Pre-paid customers redeem certificates, and spend even more</li>\r\n        <li>We provide you with a printable list of purchasers and an easy-to-use online dashboard, making redemption easy to manage</li>\r\n    </ul>\r\n    </li>\r\n</ol>', 1, '2011-11-16'),
(11, '', 'Press', '<div>\r\n<p>We are a online service for group discounts. We only feature the best deals for our customers at a discounted price which is simply unbelievable. Our company model is very simple. we treat our customers just like way we would like to be treated.</p>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div style="float:none; margin: 14px auto 10px auto; width: 664px;"><img alt="" width="664" height="332" src="images/about_img.jpg" /></div>\r\n<div class="clear">&nbsp;</div>\r\n<div>\r\n<p><strong>We simply sell the best and quality stuaff</strong></p>\r\n</div>\r\n<div>\r\n<p>Having a discounted price is only half of the mission, the other half is that the product or service needs to be quality stuff. We have deals all over the UK with unbeatable prices just to make you, the business and us happy. At GeeLaza we are always trying something new to bring the best things to you for a price that everyone is happy about. At GeeLaza we want all our customers to be happy about our deals. everyday, every week. every month. every year. All deals at GeeLaza will last only 1 day unless otherwise stated. We can assure you that you will find fantastic deals everyday live on</p>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div>\r\n<p><strong>Previous Deals </strong></p>\r\n</div>\r\n<div>\r\n<p>Click on &quot;<a href="#">Previous Deals</a>&quot; to see for yourself our great deals that has been bought over hundred times by our great customers. To make sure you don''t miss our great. unbeatable deals just subsribe to our newsletter and check out GeeLaza deals everyday. GeeLaza . waiting to be purchased.</p>\r\n<p>&nbsp;</p>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div>\r\n<p><strong>Here is how you can buy these amazing deals in few simple steps:</strong></p>\r\n</div>\r\n<div>\r\n<p>1. Buy you deal online buy ckick the &quot;<a href="#">BUY THIS DEAL</a>&quot; button and pay for the deal with your preferred payment method.</p>\r\n<p>2. When the payment is completed successfully you will receive an email with your voucher details from GeeLaza. When you have received your voucher then print it and show it to the merchant when you redeem it. Or you can redeem your voucher online using the voucher code depending on the deal offer.</p>\r\n<p>We can only present you these deals but it really depends on deal reaching its tipping point so to make sure you get your deal then spread the word and make the most of your city at amazing discounted prices.</p>\r\n</div>', 1, '2011-11-16'),
(12, '', 'Contact us', '<div class="contact_us">\r\n<p>Before contacting us, we recommend you to check our <a href="#">FAQs</a> page as we have posted the solution to most common enquires.</p>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div class="contact_us">\r\n<p>Customer section</p>\r\n<div><span>GeeLaza UK-customer Service</span><br />\r\n<span>E-mail: <a href="#"><span>support@geelaza.co.uk</span></a></span></div>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div class="contact_us">\r\n<p>Business section</p>\r\n<div><span style="line-height: 22px;">Your business can benefit from geelaza.com a lot!</span><br />\r\n<span> So why don''t you get in contact with us to find out more about this great opportunity.</span><br />\r\n<span>Email:<a href="#"><span> business@geelaza.com</span></a> to learn how GetDeala can bring hundreds of new customers to your business!</span></div>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div class="contact_us">\r\n<p>Application section</p>\r\n<div><span>To get more details on recruting, jobs and more please get in touch with us and we will try our best to get you on board.</span><br />\r\n<span>E-mail: <a href="#"><span>jobs@geelaza.comsupport@getdeala.co.uk</span></a></span></div>\r\n</div>', 1, '2011-11-16'),
(13, '', 'Invite friend', '<p>1.Praesent consequat tempus leo in aliquet. Ut at nisi id mauris ultrices elementum vel id est</p>\r\n<p>2.Nulla vehicula sollicitudin nisl, id ullamcorper leo scelerisque quis!</p>\r\n<p>3.Praesent consequat tempus leo in aliquet. Ut at nisi id mauris ultrices elementum vel id est</p>', 1, '2011-08-12'),
(14, '', 'FAQ', '<p>&nbsp;FAQ...</p>', 1, '2011-11-16'),
(15, '', 'Universal Fine Print', '<p>&nbsp;Universal Fine Print...</p>', 1, '2011-11-16'),
(16, '', 'Jobs', '<p>&nbsp;Jobs...</p>', 1, '2011-11-16'),
(17, '', 'Get featured on GeeLaza', '<p>&nbsp;Get featured on GeeLaza...</p>', 1, '2011-11-16');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_setting`
--

CREATE TABLE IF NOT EXISTS `getdeals_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `getdeals_setting`
--

INSERT INTO `getdeals_setting` (`id`, `name`, `value`) VALUES
(1, 'deal_fee', '25'),
(3, 'dailydeal_fee', '35');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_transaction`
--

CREATE TABLE IF NOT EXISTS `getdeals_transaction` (
  `tran_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  `transaction_status` enum('success','fail','pending') NOT NULL,
  `amount` float NOT NULL,
  `qty` int(11) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `debit_amount` float NOT NULL,
  `credit_amount` float NOT NULL,
  `gateway_fee` float NOT NULL,
  `withdraw_date` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `withdraw_status` enum('refund','bought','received') NOT NULL,
  `is_refundable` enum('1','0') NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `checkout_type` varchar(255) NOT NULL,
  `wakadealsbuck_price` float NOT NULL,
  `coupon_code` varchar(255) NOT NULL,
  `redeem_status` enum('0','1') NOT NULL DEFAULT '0',
  `redeem_location` int(11) NOT NULL,
  PRIMARY KEY (`tran_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `getdeals_transaction`
--

INSERT INTO `getdeals_transaction` (`tran_id`, `order_id`, `merchant_id`, `deal_id`, `transaction_status`, `amount`, `qty`, `transaction_date`, `debit_amount`, `credit_amount`, `gateway_fee`, `withdraw_date`, `user_id`, `withdraw_status`, `is_refundable`, `transaction_id`, `checkout_type`, `wakadealsbuck_price`, `coupon_code`, `redeem_status`, `redeem_location`) VALUES
(15, 13, 2, 59, 'success', 2, 19, '2011-08-16 02:16:04', 0, 0, 0, '0000-00-00 00:00:00', 20, 'received', '0', '2J730639XT866670W', 'card', 0, '4E4B95D6P49BC', '0', 0),
(14, 12, 2, 55, 'success', 2, 259, '2011-08-16 01:36:30', 0, 0, 0, '0000-00-00 00:00:00', 20, 'bought', '0', '37H148008M281171L', 'card', 0, '4E4B95K6A49BD', '0', 0),
(16, 14, 2, 58, 'success', 2, 139, '2011-08-17 10:20:06', 0, 0, 0, '0000-00-00 00:00:00', 20, 'received', '0', '931144973L132214S', 'card', 0, '4E4B95D6A49BD', '1', 3),
(17, 15, 2, 56, 'success', 4, 278, '2011-08-17 10:35:14', 0, 0, 0, '0000-00-00 00:00:00', 20, 'received', '1', '6NR14151YF377911D', 'card', 0, '4E4B99628F63F', '0', 2);

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_users`
--

CREATE TABLE IF NOT EXISTS `getdeals_users` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address1` varchar(150) NOT NULL,
  `address2` varchar(150) NOT NULL,
  `city` varchar(50) NOT NULL,
  `deal_city` varchar(255) NOT NULL,
  `state` varchar(75) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip` varchar(15) NOT NULL,
  `business_cat` varchar(255) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `user_img` varchar(150) NOT NULL,
  `education` varchar(255) NOT NULL,
  `employment` varchar(255) NOT NULL,
  `income` varchar(255) NOT NULL,
  `own_home` enum('yes','no') NOT NULL,
  `relationship` varchar(255) NOT NULL,
  `has_children` enum('yes','no') NOT NULL,
  `status` tinyint(2) NOT NULL,
  `date_added` date NOT NULL,
  `reg_ip` varchar(255) NOT NULL,
  `work_zipcode` varchar(255) NOT NULL,
  `age_range` varchar(255) NOT NULL,
  `subscription_id` int(11) NOT NULL,
  `pref_id` int(11) NOT NULL,
  `bucks` float NOT NULL,
  `reward_participate` enum('y','n') NOT NULL DEFAULT 'n',
  `reg_type` enum('facebook','regular','exclusive','paypal','merchant') NOT NULL,
  `privileges` text NOT NULL,
  `referal_user_id` int(11) NOT NULL,
  `referal_earning` float NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `paypal_email` varchar(255) NOT NULL,
  `ccfirstName` varchar(255) NOT NULL,
  `cclastName` varchar(255) NOT NULL,
  `creditCardType` varchar(255) NOT NULL,
  `expDateMonth` varchar(255) NOT NULL,
  `expDateYear` varchar(255) NOT NULL,
  `cvv2Number` varchar(255) NOT NULL,
  `creditCardNumber` varchar(255) NOT NULL,
  `ccaddress1` varchar(255) NOT NULL,
  `cccity` varchar(255) NOT NULL,
  `ccstate` varchar(255) NOT NULL,
  `cczip` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `getdeals_users`
--

INSERT INTO `getdeals_users` (`user_id`, `first_name`, `last_name`, `details`, `email`, `password`, `address1`, `address2`, `city`, `deal_city`, `state`, `country`, `zip`, `business_cat`, `phone_no`, `fax`, `gender`, `user_img`, `education`, `employment`, `income`, `own_home`, `relationship`, `has_children`, `status`, `date_added`, `reg_ip`, `work_zipcode`, `age_range`, `subscription_id`, `pref_id`, `bucks`, `reward_participate`, `reg_type`, `privileges`, `referal_user_id`, `referal_earning`, `company_name`, `website`, `paypal_email`, `ccfirstName`, `cclastName`, `creditCardType`, `expDateMonth`, `expDateYear`, `cvv2Number`, `creditCardNumber`, `ccaddress1`, `cccity`, `ccstate`, `cczip`) VALUES
(2, '', '', '', 'abc@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'sdfds', 'fsadf', 'sdfa', '', 'asdfsd', '226', 'T6E 2C6', '', '1122334455', '3423423', '', '', '', '', '', 'yes', '', 'yes', 1, '2011-08-05', '127.0.0.1', '', '', 0, 0, 0, 'n', 'merchant', '', 0, 0, 'Unified infocom', 'www.google.com', 'dutta__1282540468_biz@rediffmail.com', '', '', '', '', '', '', '', '', '', '', ''),
(11, 'Aditya', 'Jyoti Saha', '', 'aditya@gmail.com', '057829fa5a65fc1ace408f490be486ac', 'Morepukur', 'Rishra', 'Hooghly', '', 'West Bengal', '99', '712250', '', '15978456213', '', '', '', '', '', '', 'yes', '', 'no', 1, '2011-04-20', '', '', '', 0, 0, 0, 'y', 'merchant', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(16, 'Shantimoy', 'Bardhan', '', 'shan@ymail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Bagpara', 'Morepukur', 'Rishra', '', 'West Bengal', '99', '712250', '', '56187848', '', '', '', '', '', '', 'yes', '', 'yes', 1, '2011-04-19', '', '', '', 0, 0, 0, 'y', 'merchant', '', 0, 0, 'shan infosolutions', '', 'dutta__1282540468_biz@rediffmail.com', '', '', '', '', '', '', '', '', '', '', ''),
(17, 'Rachelle-Joanne', 'Oduniyi', '', 'anneoduniyi@yahoo.com', 'e898522e51efafe52ebcf4558f14b25d', '38, Ogundana Street', 'Off Allen', 'ikeja', '', 'Lagos', '156', '10001', '', '', '', '', '', '', '', '', 'yes', '', 'yes', 1, '2011-05-23', '', '', '', 0, 0, 0, 'n', 'regular', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(20, 'ujjal', 'dutta', '', 'xyz@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', '', '', '', '', '0', '534543', '', '', '', 'male', '', '', '', '', 'yes', '', 'yes', 1, '2011-07-21', '', '36443643', '1', 0, 0, 0, 'y', 'facebook', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(43, 'sentu', '', '', 'sentu.uss@gmail.com', 'c56d0e9a7ccec67b4ea131655038d604', '', '', '', '', '', '0', '', '', '', '', 'male', '', '', '', '', 'yes', '', 'yes', 1, '2011-08-18', '192.168.1.6', '', '0', 0, 0, 0, 'y', 'regular', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(59, '', '', '', 'pete.kohlapalan@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', 'yes', '', 'yes', 0, '2011-08-08', '122.109.109.28', '', '', 0, 0, 0, 'n', 'paypal', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(61, 'ujjal', 'dutta', '', 'unified.ujjal@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', '', 'Atlanta', '', '', '0', '3432', '', '', '', '', '', '', '', '', 'yes', '', 'yes', 1, '2011-08-09', '122.176.67.21', '', '', 0, 0, 0, 'n', 'merchant', '', 20, 0, 'test company', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(64, '', '', '', 'ddsfsd@dfd.com', '202cb962ac59075b964b07152d234b70', 'ddfdsa', '', 'Atlanta', '', 'dsa', '1', '', '', '', '', '', '', '', '', '', 'yes', '', 'yes', 1, '2011-09-08', '127.0.0.1', '', '', 0, 0, 0, 'n', 'merchant', '', 0, 0, 'sdfasdf', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(66, 'Priyam', 'Ghosh', '', 'priyamghosh12@gmail.com', '6b796e9019eaae623d65105317e33a64', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'yes', '', 'yes', 1, '2011-11-14', '', '', '', 0, 0, 0, 'n', 'facebook', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(67, 'Test', 'me', 'Test details...', 'test@gmail.com', '098f6bcd4621d373cade4e832627b4f6', 'Kolkata', '', 'Kolkata', 'London', '', 'India', '700001', 'IT', 'aditya@gmail.com', '', '', '', '', '', '', 'yes', '', 'yes', 0, '2011-11-16', '', '', '', 0, 0, 0, 'n', 'facebook', '', 0, 0, 'Test B', 'google.com', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_user_preference`
--

CREATE TABLE IF NOT EXISTS `getdeals_user_preference` (
  `pref_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`pref_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=165 ;

--
-- Dumping data for table `getdeals_user_preference`
--

INSERT INTO `getdeals_user_preference` (`pref_id`, `user_id`, `category_id`) VALUES
(107, 20, 2),
(106, 20, 157),
(109, 58, 157),
(115, 2, 157),
(117, 61, 155),
(118, 61, 156),
(151, 62, 154),
(150, 62, 155),
(149, 62, 156),
(124, 43, 155),
(163, 66, 2),
(162, 66, 157),
(164, 11, 2);

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_user_referal_deal`
--

CREATE TABLE IF NOT EXISTS `getdeals_user_referal_deal` (
  `user_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  `count_referal` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `getdeals_user_referal_deal`
--

INSERT INTO `getdeals_user_referal_deal` (`user_id`, `deal_id`, `count_referal`) VALUES
(20, 12, 2);

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_user_storefollowed`
--

CREATE TABLE IF NOT EXISTS `getdeals_user_storefollowed` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  PRIMARY KEY (`follow_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `getdeals_user_storefollowed`
--


-- --------------------------------------------------------

--
-- Table structure for table `getdeals_user_subscriptions`
--

CREATE TABLE IF NOT EXISTS `getdeals_user_subscriptions` (
  `sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  PRIMARY KEY (`sub_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=212 ;

--
-- Dumping data for table `getdeals_user_subscriptions`
--

INSERT INTO `getdeals_user_subscriptions` (`sub_id`, `user_id`, `city_id`) VALUES
(156, 20, 2),
(187, 43, 1),
(174, 2, 2),
(173, 2, 1),
(178, 61, 2),
(177, 61, 3),
(188, 43, 3),
(197, 62, 3),
(181, 20, 4),
(209, 66, 2),
(208, 66, 1),
(210, 11, 3),
(211, 11, 2);

-- --------------------------------------------------------

--
-- Table structure for table `getdeals_votefaq`
--

CREATE TABLE IF NOT EXISTS `getdeals_votefaq` (
  `voteid` int(11) NOT NULL AUTO_INCREMENT,
  `faq_id` int(11) NOT NULL,
  `vote_ip` varchar(255) NOT NULL,
  `yes_count` int(11) NOT NULL,
  `no_count` int(11) NOT NULL,
  PRIMARY KEY (`voteid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `getdeals_votefaq`
--

INSERT INTO `getdeals_votefaq` (`voteid`, `faq_id`, `vote_ip`, `yes_count`, `no_count`) VALUES
(1, 3, '127.0.0.1', 0, 1),
(2, 2, '127.0.0.1', 0, 1),
(3, 7, '127.0.0.1', 0, 1);
